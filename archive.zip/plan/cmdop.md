# CmdOp — Extension-ization Plan

CmdOp (the copy / move / rename / mkdir / touch command-builder shown in
PANEL_FUNCTION) is today wired **directly** into core / app / ui: its state is a
field of `AppState`, its logic is core reducer code, its render is a core UI
module, and its keys are core `Intent` variants. This document plans moving CmdOp
behind the **Extension seam** — the same layer `PreviewExtension` uses — so that
core / app / ui touch only the generic extension interface, never CmdOp
internals. It is written to be executed; §"Migration phases" is the work plan.

Canonical rules: [doc/EXTENSION.md](../doc/EXTENSION.md) (thin-core / fat-extension,
the two seam constraints, the function-panel content model),
[doc/ARCHITECTURE.md](../doc/ARCHITECTURE.md) (the intent pipeline, the closed
Plan set), [doc/UI.md](../doc/UI.md).

## Status

- **DONE — the flip is complete, green (114 tests, 0 warnings).** CmdOp is now
  the bundled `CmdOpExtension` (`extension/cmdop.rs` + `cmdop_keymap.scm`). Core /
  app / ui reference the id `cmdop` in exactly one place — the bundled-extension
  list — satisfying the zero-edit acceptance. What landed vs. the plan:
  - Rendering uses the **direct-render hook** `Extension::render_form(frame, inner,
    ctx) -> Option<String>` (returns the title; core wraps the chrome). The old
    `render_cmdop_panel` moved wholesale; the extension self-clamps its scrolls, so
    the `event_loop` CmdOp clamp is gone.
  - State/logic moved into `CmdOpForm` (RefCell) + `handle_intent`; the listing is
    read via generic `LoadContent` → `accept_content(ReadResult::Dir)` (the form
    read bypasses the cursor-staleness gate and self-gates on `list_cwd`); the
    preview pauses content-follow while `form_owner` is set.
  - Deleted from core: `AppState.cmdop`, `CmdOpState`/`CmdOp`/`CmdOpOption`/…,
    `reducer/cmdop.rs`, `ui/middle/cmdop.rs`, all `Cmd*`/`Start{Copy,Move,Rename}`
    intents + codec strings, `SubLayout::Command`, the `sublayout-command`
    predicate, `Plan::ReadDirCmd`/`Purpose::CmdListing`, `kernel::cmdop_text_active`.
  - Palette `copy`/`move`/`rename` now come from the extension's `commands()`.
  - CmdOp reducer tests moved into `extension/cmdop.rs` tests (handle_intent /
    accept_content / returned intents).

  CmdOp = Copy / Move / Rename only (mkdir/touch already go through Select).

### P0 seams (foundation, from the first pass)

- **P0 (generic seams) — DONE.** Landed additively:
  - S1 `FunctionPanelState.form_owner` + `Intent::SetFunctionForm(Option<String>)`
    + the render-by-`form_owner` dispatch in `ui/middle/function.rs` (calls
    `extensions.find(owner).render_function`).
  - S2 `FunctionInput` + `Intent::BeginInput{purpose, seed}` + the generic
    `function_input_key` readline in the reducer + the kernel raw-key gate now
    also fires on `function.input.is_some()`. On Enter/Esc it emits
    `Extension{owner, "input-submit"/"input-cancel", {purpose, text}}`.
  - S3 `Extension::bind_services(&Arc<ResolverChain>)` (default no-op), called by
    the kernel once the chain is finalized.
  - S4/cross-panel: `FunctionRenderCtx` gained `sources: &[PathBuf]` (the file
    panel's live `targets()`), so a form's `render_function` can show the command
    sources — CmdOp is cross-panel (sources from PANEL_FILE, dest from
    PANEL_FUNCTION), which the func-only ctx could not express before.
  - `SubLayout::Command` retirement is **deferred to P2** (kept additive so P0
    stays green with CmdOp still core).
- **P1–P3 — pending** (the flip below). `RETIRE SubLayout::Command` moves to P2.

## Goal

> Move *all* CmdOp behaviour, state, and rendering into a single bundled
> `CmdOpExtension`, so that with **zero references to CmdOp outside its own files**
> (the zero-edit acceptance test), core / app / ui host it exactly as they host
> `PreviewExtension`: routing keys, blitting a `FunctionDraw`, reading dirs
> off-thread, and executing the resolver plan it emits.

The reference client is `PreviewExtension`: a "fat" extension that owns its
content (decode + stash in a `RefCell`), renders it via `render_function`, and
routes its search input through the generic `function.search` readline while the
match list — the only key-gating state — stays in `AppState`. CmdOp follows the
same split.

## Current state (baseline, already implemented)

CmdOp today is the five-behaviour model from the previous iteration: live
file-panel sources, an independent listing mark set (`list_marks`), option-label
h-scroll, a bright CLI builder, a scrollable/editable builder region, and the
`,`-never-hides rule. That behaviour is **preserved**; this plan changes *where
it lives*, not *what it does*.

### The coupling surface to dismantle

| Where | Direct CmdOp coupling today |
|-------|-----------------------------|
| `core/state.rs` | `AppState.cmdop: Option<CmdOpState>`; the `CmdOpState` struct + `preview()` / `destination()` methods |
| `core/reducer.rs` | `StartCopy/Move/Rename/Edit`, `CmdCursorUp/Down`, `CmdDescend/Parent`, `CmdSectionToggle`, `CmdOptionToggle`, `CmdConfirm`, `CmdCancel`, `CmdFilterStart`, `CmdListResult` intent arms; the CmdOp branches inside `ToggleSelect` / `FuncUp/Down/Left/Right` / `CycleFunctionPanel` |
| `core/reducer/cmdop.rs` | the entire CmdOp reducer logic (activation, navigation, confirm, raw-key edit) |
| `core/intent.rs` | ~12 `Cmd*` / `Start*` `Intent` enum variants + their codec strings |
| `ui/middle/cmdop.rs` | the whole CmdOp renderer, reading `CmdOpState` fields directly |
| `ui/middle/function.rs` | `sublayout == Command` branch dispatching to `render_cmdop_panel(&state.cmdop, …)` |
| `app/event_loop.rs` | the post-draw `c.opt_hscroll.bind(…)` / `c.builder_scroll.bind(…)` clamp block |
| `app/kernel.rs` | `cmdop_text_active(state)` peeking `state.cmdop.{filter,prompt,builder_edit}` |
| `core/mode.rs` | `SubLayout::Command` |
| `app/keymap.scm` | all `sublayout-command` bindings |

Every row above becomes either "deleted" or "generic" after this plan.

## Target architecture — `CmdOpExtension`

A bundled extension (`extension/cmdop.rs`, id `"cmdop"`) that implements the
`Extension` trait and owns the form in interior mutability:

```rust
pub struct CmdOpExtension {
    form: RefCell<Option<CmdOpForm>>,   // was AppState.cmdop
    resolver: OnceCell<Arc<ResolverChain>>, // injected at registration (see §Seams)
}
```

`CmdOpForm` is today's `CmdOpState` **minus** the key-gating bits (which move to
generic `AppState`, below): op, command skeleton, options + checks, listing
entries + `list_cwd`, the unified cursor, `list_marks`, `on_builder`, the two
`Scroll`s (now self-clamped by the extension — see §Rendering), and the dest
resolution (`preview()` / `destination()` move here verbatim).

Trait methods used:

| Method | CmdOp's use |
|--------|-------------|
| `id` / `scheme_source` / `register_conditions` | id `"cmdop"`; declares its keymaps + the `cmdop-active` `:when` predicate (reads generic `AppState`, see below) |
| `handle_intent(ei, &AppState) -> Vec<Intent>` | the **only** logic entry: activation, navigation, toggles, confirm/execute, text-input submit/cancel — mutates `form`, returns generic core intents |
| `accept_content(path, &ReadResult::Dir)` | receives the listing directory core read off-thread, stashes entries into `form` (reuses the generic Read path — no `ReadDirCmd`) |
| `render_function(ctx) -> FunctionDraw` | renders the whole panel windowed to `ctx.height` (absorbs `ui/middle/cmdop.rs`) |
| `bind_store` (or a new `bind_services`) | receives the resolver handle for option/skeleton lookup at activation |

## Generic seams core must provide (one-time framework)

Building these is *not* a zero-edit violation (doc/EXTENSION.md: "does not forbid
the one-time generic framework that hosts extensions"). Each is generic — no
"cmdop" string in core — and reusable by any future interactive-form extension.

### S1 — `form_owner`: an interactive-form host indicator

Add `FunctionPanelState.form_owner: Option<String>` — the id of the extension
currently hosting an **interactive form** in the panel (distinct from the passive
`content_owner` cursor-follow content). Generic setter intents
`SetFunctionForm(Option<String>)` (or fold into an existing show/hide intent):

- Set to `Some("cmdop")` on activation; the panel becomes visible + focused.
- `render` dispatches: when `form_owner` is `Some(id)`, draw via
  `extensions.find(id).render_function(ctx)` (the form owns the whole inner
  rect), replacing the `sublayout == Command` branch. When `None`, the existing
  content path runs.
- The extension registers a `:when` predicate `cmdop-active` reading
  `state.function.form_owner.as_deref() == Some("cmdop")` — satisfying **seam
  constraint 1** (`:when` reads only `&AppState`). This is what gates every CmdOp
  key without core knowing what "cmdop" is.

`SubLayout::Command` is **retired**; `form_owner` subsumes it. `SubLayout` keeps
`{Content, Exec}`.

### S2 — generic extension text-input (readline) seam

Generalize the `function.search` readline (`input_active` + `query`/`caret`,
kernel raw-routing, reducer `readline_query`) into a reusable text input any
form extension can request:

- `FunctionPanelState.input: Option<InputState>` with `{ query, caret, purpose:
  String }`. `input.is_some()` replaces both `search.input_active` **and**
  `cmdop_text_active` in the kernel's raw-key gate (§`handle_key`).
- Handler asks for input by returning `Intent::BeginInput{purpose, seed}`
  (generic): the reducer sets `function.input`. The kernel raw-routes keys; the
  reducer edits the buffer generically.
- On Enter/Esc the reducer emits `Intent::Extension{owner: form_owner, intent:
  "input-submit"/"input-cancel", data: query}`; the extension consumes it
  (filter → filter the listing; prompt → set dest + confirm; builder-edit → run).

This makes CmdOp's three text inputs (filter `/`, dest prompt, builder edit) —
and the preview search — one mechanism. The buffer stays in `AppState` because it
gates keys (**constraint 1**); the *meaning* of the submitted text is the
extension's.

### S3 — resolver lookup handle for the extension

`activate` needs `resolver.options(key)` (parsed `--help`) and
`resolver.command(key)` (the skeleton) — today via the reducer's `CmdCtx`
(`CommandLookup`), which `handle_intent` does **not** receive. Inject the handle
once at registration (a `bind_services(&ResolverChain)` method mirroring
`bind_store`), stored in the extension's `OnceCell`. No per-call ctx threading.

### S4 — render dispatch by owner (small)

`ui/middle/function.rs` already keys content off `content_owner`/`provider()`;
extend it to prefer `form_owner` (S1). The `FunctionDraw` blitter, border, title,
and scrollbar chrome are unchanged and stay core.

## Rendering: a direct-render hook (`render_form`) — chosen over `FunctionDraw`

CmdOp has three independent scroll regions (builder / options / listing) with
per-section scrollbars, a cursor, and an edit caret — genuinely a *panel*, not a
windowed lines blob. Runtime cost of "build `Vec<Line>`" vs "draw into the frame"
is identical (both O(panel cells), a cold path), so the decision is
implementation cost + expressiveness. Chosen: a **generic direct-render hook**,
which lets the existing `render_cmdop_panel` move almost verbatim (no lossy
line-baking rewrite) and expresses multi-section scrollbars naturally.

Add one trait method (the deferred "per-panel renderer" surface, built now as a
bundled-only, non-ABI one-time framework):

```rust
/// Draw an interactive form into the panel's inner rect; return its title (core
/// wraps the border/title/open-bottom chrome). None = not hosting a form.
fn render_form(&self, frame: &mut Frame, inner: Rect, ctx: &FunctionRenderCtx) -> Option<String> { None }
```

Core stays the thin host: `ui/middle/function.rs` calls `render_form` under
`form_owner`, then pushes a `PanelFrame::new(area).title(title).focused(ctx.focused).open_bottom(true)`
— border, title, and rect remain core; only the interior is the extension's. The
Extension trait already imports `ratatui::text::Line`; it gains `Frame` / `Rect`.

- The extension **self-clamps** `opt_hscroll` / `builder_scroll` inside
  `render_form` (it has `ctx.height`/`ctx.width` and interior mutability), so the
  `app/event_loop.rs` CmdOp clamp block is **removed** — no kernel round-trip.
- `ui/middle/cmdop.rs` (renderer + `wrapped_rows` + `render_section_scrollbar`)
  moves wholesale into `extension/cmdop.rs::render_form`, dropping only the
  `panels`/`mem`/`area` params (title is returned; scroll self-clamped).

### Seam refinements discovered during P0

- **Listing read is not cursor-gated.** The generic `LoadContent`→`Plan::Read`
  path drops results whose path ≠ the file cursor (`cursor_signature`), which
  would drop CmdOp's `list_cwd` dir read. Fix generically: the staleness gate
  applies only to the **content provider's** cursor-follow reads; a *form*
  owner's read bypasses it and self-gates in `accept_content` (compare
  `path == form.list_cwd`). This replaces the CmdOp-specific `Plan::ReadDirCmd` /
  `Purpose::CmdListing` / `Intent::CmdListResult` with the generic read path.
- **Live filter without per-keystroke intents.** The `/` filter is incremental.
  The generic `FunctionInput` only hands text back on Enter/Esc, but `render_form`
  reads `ctx.func.input` every frame, so the extension filters the listing live
  from `input.query` while `purpose == "filter"`, and persists it into the form on
  submit. Same for the dest **prompt** (rename/mkdir/touch) and the **builder
  edit** — all three CmdOp text inputs are the one generic `FunctionInput`,
  disambiguated by `purpose`.
- **Focus on activation.** `SetFunctionForm(Some)` shows the panel but does *not*
  move focus (generic); the extension appends `FocusPanel(PANEL_FUNCTION)` for
  rename/mkdir/touch and leaves file focus for copy/move (matching today).
- **Confirm.** `handle_intent` returns `Intent::RunResolver(req)` (the existing
  Policy-gated path) + `SetFunctionForm(None)`; builder-edit returns
  `Intent::Execute{argv}` + `SetFunctionForm(None)`.

## Flows

Activation (`c` → start copy), all keys are Extension-layer bindings the
extension declares in `scheme_source`:

```
c ─▶ (ext "cmdop" "start-copy")
   ▼ kernel dispatch ─▶ CmdOpExtension.handle_intent("start-copy", &state)
        reads state.targets() (sources) + resolver.options/command (S3)
        stashes CmdOpForm in RefCell
        returns: [ SetFunctionForm(Some("cmdop")),         // S1: show+focus panel
                   LoadContent{owner:"cmdop", path:list_cwd} ]  // read the listing dir
   ▼ kernel: Plan::Read ─▶ worker ─▶ ReadResult::Dir ─▶ cmdop.accept_content (stash entries)
   ▼ render: form_owner=="cmdop" ─▶ cmdop.render_function ─▶ core blits
```

Navigation (`j` while active): `(ext "cmdop" "cursor-down")` gated by
`cmdop-active` → `handle_intent` mutates the form cursor → returns `[]` → the
next frame re-renders from the form. No core intent, no `AppState` write.

Confirm (`Enter` on a body row): `handle_intent("confirm")` builds a
`ResolverRequest` from the form + `state.targets()` and returns an **extension
intent carrying the reserved `resolver` key** — the kernel runs it through the
chain with Policy confirmation (doc/EXTENSION.md §"Extension Intents"), then the
handler returns `SetFunctionForm(None)` to close. Builder-edit Enter returns the
core `Intent::Execute{argv}` (a core capability) + `SetFunctionForm(None)`.

## What moves where

| Concern | From | To |
|---------|------|----|
| Form state (`CmdOpState`) | `AppState.cmdop` | `CmdOpExtension.form` (`RefCell`) |
| Activation / nav / confirm / raw-edit logic | `core/reducer/cmdop.rs` | `CmdOpExtension::handle_intent` |
| `preview()` / `destination()` | `core/state.rs` | `CmdOpForm` (in the extension) |
| Renderer + `wrapped_rows` + section scrollbar | `ui/middle/cmdop.rs` | `CmdOpExtension::render_function` |
| Listing directory read | `Plan::ReadDirCmd` | generic `LoadContent` → `accept_content(ReadResult::Dir)` |
| Option / builder scroll clamp | `app/event_loop.rs` | extension self-clamp in `render_function` |
| Text-input active gate | `kernel::cmdop_text_active` | generic `function.input.is_some()` (S2) |
| `Cmd*` / `Start*` intents | `core/intent.rs` enum | Extension intents (data), declared in the `.scm` |
| CmdOp keymaps | `app/keymap.scm` | `CmdOpExtension::scheme_source` |
| `sublayout == Command` dispatch | `ui/middle/function.rs` | generic `form_owner` dispatch (S1/S4) |
| `SubLayout::Command` | `core/mode.rs` | removed |

## The two seam constraints (doc/EXTENSION.md) — how CmdOp satisfies them

1. **`:when` reads only `&AppState`.** The gate for every CmdOp key is
   `cmdop-active` = `form_owner == "cmdop"`, and the text-input gate is
   `function.input.is_some()` — both generic `AppState`. The bulky form state
   (options, entries, marks, cursor) gates nothing, so it lives in the extension.
2. **The reducer can't call extensions.** All CmdOp logic runs in
   `handle_intent`, reached only through the **kernel** dispatch of
   `Intent::Extension`. CmdOp keys therefore bind to extension intents (not core
   intents); the reducer only applies the generic intents the extension returns
   (`SetFunctionForm`, `BeginInput`, `LoadContent`, `Execute`, the resolver plan).

## Migration phases

- **P0 — generic seams.** Add S1 (`form_owner` + render dispatch + retire
  `SubLayout::Command`), S2 (`function.input` generic readline; migrate the
  preview search onto it), S3 (`bind_services` resolver handle), S4 (render by
  owner). Land with existing behaviour intact (CmdOp still core, temporarily
  driving the new seams). Tests: the preview search still works on S2.
- **P1 — the extension shell.** Create `extension/cmdop.rs` with `CmdOpForm`
  (moved `CmdOpState` + `preview`/`destination`) and `render_function` (moved
  `ui/middle/cmdop.rs`), driven by a thin `handle_intent` that still delegates to
  the old reducer functions. Register it (bundled list). Render via `form_owner`.
- **P2 — cut the core intents.** Replace `Start*` / `Cmd*` intents and the
  `keymap.scm` `sublayout-command` block with the extension's Extension-layer
  bindings + `scheme_source`; move the logic bodies into `handle_intent`; delete
  `core/reducer/cmdop.rs`, the CmdOp branches in `ToggleSelect`/`Func*`/`Cycle*`,
  `AppState.cmdop`, `ui/middle/cmdop.rs`, the `event_loop` clamp, and
  `cmdop_text_active`.
- **P3 — tests + docs.** Move the CmdOp reducer tests to extension tests
  (drive `handle_intent` + assert returned intents / `form` state); update
  doc/UI.md + doc/EXTENSION.md (CmdOp joins the bundled list as the reference
  *interactive-form* extension, next to preview the reference *content* one).

Each phase compiles and passes tests; P2 is the one that flips ownership.

## Zero-edit acceptance

After P2, grepping `crates/wasdf/src/` for `cmdop` / `CmdOp` / `start-copy` /
`cmd-cursor` outside `extension/cmdop.rs` (+ the bundled-list line and the
`.scm`) returns nothing — the same acceptance test the other bundled extensions
pass. The core `Intent` enum is **smaller** (≈12 variants removed); `AppState`
loses a field; three core files (`reducer/cmdop.rs`, `ui/middle/cmdop.rs`, the
`SubLayout::Command` arm) disappear.

## Risks / open questions

- **`FunctionDraw` expressiveness.** Pre-windowing the whole panel into `lines`
  is confirmed sufficient (preview already owns h-scroll / highlight / numbers in
  its lines); the only new demand is drawing *section* scrollbars as glyphs — a
  render detail, no new core vocabulary. If a future form needs true 2-D cell
  control, that is the deferred "per-panel renderer" trait surface, out of scope.
- **`resolver` reserved-key plan vs. `RunResolver`.** Confirm the extension-intent
  resolver path (with the `resolver` key) gives the same Policy-confirmation
  behaviour as today's `Intent::RunResolver` (delete → Policy). Expected yes
  (kernel `dispatch_depth` handles both); verify in P2.
- **Focus / `,`-never-hides.** The `,` (cycle) + skip-hidden rule currently reads
  `state.cmdop.is_some()`. Re-express as `form_owner.is_some()` (generic) so
  `cycle_function_panel` never hides a hosted form — no CmdOp reference remains.
- **Generic input purpose routing.** S2's `purpose` tag must disambiguate CmdOp's
  three inputs; keep the tag opaque to core (the extension owns its meaning).

## Requirement → change (this plan)

| Aim | Core (generic, one-time) | Extension (`extension/cmdop.rs`) | Deleted from core |
|-----|--------------------------|----------------------------------|-------------------|
| Host without knowing CmdOp | S1 `form_owner` + render-by-owner; S4 | implements `render_function` | `sublayout == Command`, `ui/middle/cmdop.rs` |
| Route keys | Extension dispatch (exists) | `scheme_source` keymaps + `cmdop-active` predicate | `Cmd*`/`Start*` intents, `keymap.scm` block |
| Own state/logic | — | `CmdOpForm` + `handle_intent` | `AppState.cmdop`, `reducer/cmdop.rs` |
| Text input | S2 generic `function.input` | `input-submit`/`input-cancel` handling | `cmdop_text_active` |
| Read the listing | `LoadContent`/`Read` (exists) | `accept_content(ReadResult::Dir)` | `Plan::ReadDirCmd` |
| Scroll bounds | — | self-clamp in `render_function` | `event_loop` CmdOp clamp |
| Run the command | resolver reserved key / `Execute` (exist) | build request in `handle_intent` | `confirm_cmdop` in core |
