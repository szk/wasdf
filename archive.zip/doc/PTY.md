# PTY Extension

`pty` is a bundled extension that allocates pseudo-terminals, runs child
processes on them, and renders their screens inside `PANEL_FUNCTION`. It is the
host for three things: a free-standing shell session, the process CmdOp's CLI
builder launches, and (optionally) the editor `StartEdit` opens.

This document is the canon for the extension. It assumes
[ARCHITECTURE.md](ARCHITECTURE.md) (the intent pipeline, the closed Plan set,
the async contract), [EXTENSION.md](EXTENSION.md) (the Extension trait, the
Zero-Edit Principle), and [UI.md](UI.md) (the function panel, `form_owner`,
focus).

The extension id is **`pty`**. The string `"pty"` must not appear anywhere in
`core/`, `app/`, `script/`, `exec/`, `ui/`, or `vfs.rs` except in
`extension::bundled()` — that is the Zero-Edit acceptance test. Everything this
document adds to core is *generic vocabulary*: raw input capture, an event
wake-up channel, and a faithful `Key`. Each is usable by any extension.

---

## 1. Why core has to change

A PTY is the first thing wasdf hosts that is **long-lived, bidirectional, and
self-driven**. Three existing invariants do not accommodate it, and this
document's core additions exist only to close those three gaps.

| Gap | Today | Why a PTY breaks on it |
|-----|-------|------------------------|
| **Raw input** | `RawKeyEvent` is emitted only when no keymap binding matches, and `reducer.rs` consumes it entirely (Select query / search input). It never reaches an extension. | A terminal must receive *every* key, including ones that are bound (`q`, `Ctrl-C`), while still leaving core an unconditional way back out. |
| **Key fidelity** | `KeyCode` has 15 variants (no F-keys, no Insert). `Mods` has ctrl/shift/alt only. `convert_key` drops `KeyEventKind::Release` and folds shift into the char. | A child process needs the real key, modifiers, and event kind. |
| **Repaint** | The event loop blocks on `rx.recv()`; when idle, the input thread emits `AppEvent::Tick` every 250 ms (`event::poll(Duration::from_millis(250))`). | 4 fps. A terminal must repaint when the child writes, not on a timer. |

What does **not** need to change: rendering. `Extension::render_form(&self,
frame: &mut Frame, inner: Rect, ctx)` is already a bundled-only raw ratatui
surface into the function panel's inner rect, and `tui-term` provides
`impl Widget for &PseudoTerminal`. No `PanelView` variant is added.

---

## 2. Core additions

Nine touch points. Implement them in this order; each is independently testable.

### C1 — `Key` fidelity (`core/intent.rs`, `app/terminal.rs`)

`KeyCode` gains the codes a modern terminal reports:

```rust
pub enum KeyCode {
    // … existing 15 variants unchanged …
    Insert,
    /// F1–F35 (Kitty reports up to F35).
    F(u8),
}
```

`Mods` gains the Kitty modifier set. Existing `Mods { ctrl, shift, alt }`
literals must be updated — there are exactly **5** construction sites
(`core/intent.rs:45,46`, `app/terminal.rs:95`, and two in tests); prefer
`..Mods::NONE` in new code.

```rust
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, Hash)]
pub struct Mods {
    pub ctrl: bool,
    pub shift: bool,
    pub alt: bool,
    /// Cmd on macOS, Win on Windows/Linux. Reported only under the Kitty
    /// keyboard protocol; always false on a legacy terminal.
    pub sup: bool,
    pub hyper: bool,
    pub meta: bool,
}
```

`Key` gains the event kind:

```rust
/// Press / repeat / release. Legacy terminals report `Press` only; `Repeat`
/// and `Release` arrive under the Kitty protocol's `REPORT_EVENT_TYPES`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum KeyKind { #[default] Press, Repeat, Release }

pub struct Key {
    pub code: KeyCode,
    pub mods: Mods,
    pub kind: KeyKind,
}
```

`Key::new` / `Key::plain` keep their signatures and default `kind` to `Press`,
so no existing call site changes.

`app/terminal.rs::convert_key` stops discarding releases:

```rust
pub fn convert_key(ev: KeyEvent) -> Option<Key> {
    let kind = match ev.kind {
        KeyEventKind::Press => KeyKind::Press,
        KeyEventKind::Repeat => KeyKind::Repeat,
        KeyEventKind::Release => KeyKind::Release,
    };
    // … existing code mapping, plus CtKeyCode::Insert and CtKeyCode::F(n) …
}
```

**Shift folding stays as it is** (`shift` is kept only for non-char codes),
because the keymap depends on it. The PTY encoder (§5.3) re-derives shift from
the character itself; that is lossless for the cases a child cares about.

**Keymap resolution must ignore non-press events.** In
`KeymapRegistry::resolve`, return `None` for `key.kind != KeyKind::Press`.
Without this, every keystroke fires its binding twice under the Kitty protocol.

### C2 — Kitty keyboard protocol on wasdf's own terminal (`app/terminal.rs`)

```rust
use crossterm::event::{
    KeyboardEnhancementFlags, PopKeyboardEnhancementFlags, PushKeyboardEnhancementFlags,
    supports_keyboard_enhancement,
};

/// Kitty flags wasdf asks its own terminal for. Best-effort: a terminal that
/// does not support them is left alone and everything degrades to legacy keys.
const KITTY_FLAGS: KeyboardEnhancementFlags = KeyboardEnhancementFlags::DISAMBIGUATE_ESCAPE_CODES
    .union(KeyboardEnhancementFlags::REPORT_EVENT_TYPES)
    .union(KeyboardEnhancementFlags::REPORT_ALTERNATE_KEYS)
    .union(KeyboardEnhancementFlags::REPORT_ALL_KEYS_AS_ESCAPE_CODES);
```

- `init()` — after `ratatui::init()`, if `supports_keyboard_enhancement()`
  returns `Ok(true)`, `execute!(stdout(), PushKeyboardEnhancementFlags(KITTY_FLAGS))`
  and record that it was pushed in a module-level `AtomicBool`.
- `restore()` — pop if pushed, before `ratatui::restore()`.
- `run_suspended()` — the pop/push must bracket the child, exactly as the
  alternate screen already does. Do it inside the existing `restore()` /
  `init()` calls, so no extra code is needed there.

Failure to push is not an error: log to `@/messages`, continue. This follows
the project's **disable, notify, continue** rule.

### C3 — Raw input capture (`core/state.rs`, `core/intent.rs`, `core/reducer.rs`, `script/codec.rs`)

```rust
// core/state.rs
/// An extension's claim on the raw keyboard. While one is installed,
/// `handle_key` delivers keys to `owner` instead of acting on them — except
/// for the two escapes below, which core itself honours. The escapes are
/// **data owned by core**, not a protocol the extension has to implement, so
/// they keep working even if the extension is wedged.
#[derive(Debug, Clone, PartialEq)]
pub struct InputCapture {
    /// The extension receiving captured keys.
    pub owner: String,
    /// The hard release key. Core clears the capture on it unconditionally,
    /// then delivers it to `owner` as `intent = "prefix"` so the extension can
    /// react. This is the lockout guarantee: it does not depend on the
    /// extension answering.
    pub release: Key,
    /// Intents that also end the capture. Core resolves each key through the
    /// keymap as usual; if the result is in this set, the capture is cleared
    /// **and the intent is dispatched normally**, so the action the user
    /// pressed the key for actually happens. Empty = only `release` escapes.
    pub escape: Vec<Intent>,
}

// on AppState
pub input_capture: Option<InputCapture>,
```

```rust
// core/intent.rs
/// Boxed, like `PushMode`: `InputCapture` carries a `Vec<Intent>`, and an
/// unboxed variant would widen every `Intent` in the program.
SetInputCapture(Option<Box<InputCapture>>),
```

Reducer: `Intent::SetInputCapture(c) => { state.input_capture = c.clone(); Effects::none() }`.

A `:when` condition `input-captured` is registered by core alongside the
existing ones, so keymaps can gate on it.

`InputCapture` is not decoded from Scheme — it carries an `Intent` list, which
the keymap codec builds statically without state access. Capture is always
installed by an extension from `handle_intent`.

### C4 — Key delivery under capture (`app/kernel.rs`)

At the very **top** of `App::handle_key`, before the search-input and
form-input branches:

```rust
if let Some(cap) = self.state.input_capture.clone() {
    // 1. The hard release. Checked first and honoured unconditionally: this is
    //    the only thing standing between a wedged extension and a user who
    //    cannot quit.
    if key == cap.release {
        self.dispatch(Intent::SetInputCapture(None));
        self.dispatch(Intent::Extension(ExtensionIntent {
            extension: cap.owner,
            intent: "prefix".into(),
            data: ExtensionValue::Nil,
        }));
        self.broadcast_cursor_changed();
        return;
    }
    // 2. Intent escapes. Resolve through the keymap exactly as an uncaptured
    //    key would; if the user pressed something that means "move the
    //    cursor", release and let it mean that.
    if !cap.escape.is_empty() {
        let panel = self.state.focused_panel.clone();
        if let Some(intent) = self.keymap.resolve(&self.conditions, &self.state, &panel, key) {
            if cap.escape.contains(&intent) {
                self.dispatch(Intent::SetInputCapture(None));
                self.dispatch(intent);
                self.broadcast_cursor_changed();
                return;
            }
        }
    }
    // 3. Everything else is the extension's.
    self.dispatch(Intent::Extension(ExtensionIntent {
        extension: cap.owner,
        intent: "key".into(),
        data: encode_key(key),
    }));
    self.broadcast_cursor_changed();
    return;
}
```

This reuses the existing extension-dispatch stage of `dispatch_intent`; the
reducer is untouched and stays pure.

Two properties fall out of doing the escape check in core rather than in the
extension, and both matter:

- **The escape is declared as intents, not keys.** A user who rebinds
  navigation to `hjkl` or the arrow keys gets those as the escape too, for free.
  Nothing hardcodes `w`/`a`/`s`/`d` anywhere.
- **No dispatch-ordering hazard.** The capture is cleared and the intent
  dispatched in one place, in that order, by core. The extension never has to
  "release then replay", which would have depended on `dispatch_intent`
  applying the reducer's state change before the next queued intent.

Step 2 is skipped entirely when `escape` is empty, so a shell session pays only
one `Key` comparison per keystroke.

`encode_key` lives in `script/codec.rs` next to `key_name` / `parse_key`, and
is lossless (`key_name` is not — it has no form for `kind` or the new
modifiers):

```rust
/// A `Key` as an `ExtensionValue::Map`, lossless and ABI-safe:
///   "code"  → String, the `key_name` spelling of the bare code ("a", "F5", "Left")
///   "ctrl" "shift" "alt" "super" "hyper" "meta" → Bool
///   "kind"  → String, "press" | "repeat" | "release"
pub fn encode_key(key: Key) -> ExtensionValue;
pub fn decode_key(v: &ExtensionValue) -> Option<Key>;
```

Extend `key_name` / `parse_key` for `Insert`, `F(n)` (`"F5"`), and the new
modifier prefixes — `"Super-"`, `"Hyper-"`, `"Meta-"`, matching the existing
`Ctrl-` / `Alt-` / `Shift-` word form — so that `pty.prefix-key` can be written
`"Ctrl-b"` in `config.scm` and parsed by the existing `parse_key`.

**Lockout.** The `release` key is checked before anything else and is honoured
by core alone, so a panicking or deadlocked extension cannot trap the user: the
capture is gone the moment `Ctrl-b` is pressed, whether or not the extension
responds to the `"prefix"` intent that follows.

### C5 — Repaint wake-up (`extension.rs`, `app/kernel.rs`)

One new default-no-op method on the `Extension` trait:

```rust
/// Hand the extension a clone of the event-loop sender so an extension that
/// owns its own I/O source (a PTY reader thread, a file watcher) can wake the
/// loop when its state changes out of band. Bundled-only: `Sender<AppEvent>`
/// does not cross the C ABI, so the dynamic loader never calls this.
/// Called once at registration, after `bind_store`. Default no-op.
fn bind_events(&self, _tx: std::sync::mpsc::Sender<AppEvent>) {}
```

Wake-ups are sent as `AppEvent::Tick` — an existing variant that the loop
already treats as "redraw, no state change". No new `AppEvent`, no new `Plan`,
no new `Purpose`.

### C6 — The per-pass tick hook (`extension.rs`, `app/kernel.rs`, `app/event_loop.rs`)

```rust
/// Called once per event-loop pass, idle ticks included. For an extension
/// whose state can change with no intent behind it — a child process exiting,
/// a watched file changing — this is the only place that change can become
/// intents. Keep it cheap; it runs for every extension, every pass.
fn on_tick(&self, _state: &AppState) -> Vec<Intent> { Vec::new() }
```

`App::tick()` collects and re-dispatches them; the event loop calls it *after*
handling each event, so an extension sees the state that pass produced.

`on_cursor_changed` cannot serve this purpose: it is deduplicated on the cursor
signature, so it never fires when nothing the user did has changed — which is
exactly the case for a child that exited on its own thread.

### C7 — The function panel's title has one source (`ui/`)

The top area draws the function panel's label on the border row the two share
(doc/UI.md), and it used to derive that label from `state.current_entry()` —
the file cursor's name. That is right only for a preview. Anything else owning
the panel (the CmdOp builder, a PTY session) named itself and was never heard,
and even the preview's own search-match counter never appeared.

- `ScrollMemory` gains `function_title: Option<String>`, cleared by
  `reset_function_bounds` and set by **every** producer of a function-panel
  `PanelFrame`.
- `ui/render.rs` draws the middle area **before** the top area, so the label is
  known by the time the top border is written.
- `render_top` takes the recorded title instead of computing one.

### C8 — A hosted form can scroll (`extension.rs`, `ui/middle/function.rs`)

```rust
/// The scroll extent of the form this extension just drew, as
/// `(total rows, position)`. Core turns it into the same scrollbar and the
/// same post-draw scroll clamp every other function-panel frame gets.
/// `None` (the default) means the form does not scroll.
fn form_scroll(&self, _ctx: &FunctionRenderCtx) -> Option<(usize, usize)> { None }
```

The form branch routes a `Some` through the existing `push_function`, so a
hosted form gets the panel's ordinary scrollbar and clamp rather than being a
special case.

Core also frees `x`: it was bound to the command palette in both
`script/keymap.rs` and `app/keymap.scm`, and the palette already has `z`.

### C9 — Cursor-changed re-runs once when the panel is handed back (`app/kernel.rs`)

A content provider declines to follow the cursor into a panel it does not own
(`form_owner.is_some()` — see `PreviewExtension::cursor_target`). So when a
hosted form steps aside *during* the cursor-changed broadcast, everyone who ran
before it has already declined, and the panel is left empty.

`broadcast_cursor_changed` therefore notifies subscribers a second time if the
form owner went from `Some` to `None` during the first pass. Exactly once: the
panel cannot be handed back twice, so it cannot recurse. Without this, moving
the file cursor off a terminal leaves a blank panel until the *next* move.

No new `Plan`, no new `Purpose`, no `PanelView` variant, no `SubLayout`
variant. PTY writes happen inside `handle_intent` (§5.4) — the one documented
deviation from "all I/O lives in kernel async tasks".

---

## 3. Module layout

`no mod.rs` — the facade is `<dirname>.rs`.

```
crates/wasdf/src/extension/pty.rs             facade: `mod` declarations + re-exports
crates/wasdf/src/extension/pty/extension.rs   PtyExtension: the Extension impl
crates/wasdf/src/extension/pty/session.rs     Session: one PTY + child + parser + reader thread
crates/wasdf/src/extension/pty/sessions.rs    SessionTable: the live map, id allocation
crates/wasdf/src/extension/pty/encode.rs      Key -> child bytes (legacy + Kitty CSI-u)
crates/wasdf/src/extension/pty/kbmode.rs      sniff the child's keyboard-mode stack from its output
crates/wasdf/src/extension/pty/provider.rs    PtyProvider: the `@/pty` VfsProvider
crates/wasdf/src/extension/pty/keymap.scm     entry bindings
crates/wasdf/src/extension/pty/options.scm    option declarations
```

Register in `extension::bundled()`:

```rust
Box::new(pty::PtyExtension::new(/* nothing yet */)),
```

`PtyExtension` must be `Send` (the trait requires it) but is only ever touched
on the main thread; all cross-thread state lives behind the `Arc`s described in
§4.

---

## 4. Session model

```rust
/// A monotonically increasing per-process id. Never reused, so `@/pty/<id>`
/// paths stay stable for the life of the process.
pub type SessionId = u64;

/// How a session gives keyboard control back to wasdf. Every session releases
/// on the prefix key (`pty.prefix-key`, default `C-b`) — that is core's
/// unconditional guarantee, see §C4. This enum picks the *additional*
/// release path a session class may ask for, and it is expressed as intents,
/// never as keys, so it follows the user's keymap.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EscapeClass {
    /// Prefix key only. Everything else — including cursor movement — goes to
    /// the child. Used by `Origin::Shell` and `Origin::Edit`: a shell and an
    /// editor both need the full alphabet.
    PrefixOnly,
    /// Prefix key, plus **every** file-cursor move. Used by `Origin::Command`,
    /// where the child is a one-shot command whose interaction is at most a
    /// `y/n` prompt, so surrendering the movement keys costs nothing and puts
    /// the file cursor one keystroke away.
    PrefixAndCursor,
}

impl EscapeClass {
    /// The `InputCapture::escape` set this class installs.
    ///
    /// All six navigation intents, not just the four WASD moves: reaching for
    /// the top or the bottom of the listing is the same gesture as stepping
    /// through it, and a session that broke out on `s` but swallowed
    /// `CursorBottom` would be arbitrary. `Activate` and `NavigateTo` are
    /// deliberately *not* here — those act on an entry, and acting on the file
    /// panel while a command is still running is a different decision from
    /// merely looking away from it.
    fn intents(self) -> Vec<Intent> {
        match self {
            EscapeClass::PrefixOnly => Vec::new(),
            EscapeClass::PrefixAndCursor => vec![
                Intent::CursorUp,
                Intent::CursorDown,
                Intent::CursorLeft,
                Intent::CursorRight,
                Intent::CursorTop,
                Intent::CursorBottom,
            ],
        }
    }
}

/// Why the session exists. Drives the `@/pty` label and the exit behaviour.
#[derive(Debug, Clone, PartialEq)]
pub enum Origin {
    /// A free-standing interactive shell the user opened.
    Shell,
    /// A command CmdOp's builder assembled. `label` is the command line.
    Command { label: String },
    /// The editor `StartEdit` opened on `path`.
    Edit { path: PathBuf },
}

pub struct Session {
    pub id: SessionId,
    pub origin: Origin,
    pub escape: EscapeClass,
    /// The command line, for `@/pty` display and the completion notice.
    pub argv: Vec<String>,
    pub cwd: PathBuf,

    /// vt100 screen state. Written by the reader thread, read by `render_form`.
    /// A `Mutex` (not `RwLock`): the reader is the only writer and holds it for
    /// microseconds per chunk.
    pub parser: Arc<Mutex<vt100::Parser>>,
    /// The child's keyboard-protocol mode stack, updated by the same reader
    /// thread from the same bytes (see §5.3).
    pub kbmode: Arc<Mutex<kbmode::Stack>>,

    /// **The write half lives in `Shared`, not here.** `take_writer` may only
    /// be called once per master, and the reader thread needs it too: a child
    /// that sends the keyboard-protocol query (`CSI ? u`) blocks until the
    /// reply is written back into its own input.
    /// Kept alive so the PTY is not closed, and so `resize` can be called.
    /// `MasterPty` is `Send` but **not** `Sync`, so this never leaves the main
    /// thread.
    master: Box<dyn portable_pty::MasterPty + Send>,
    /// The `Child` itself is **moved into the reader thread**, because
    /// `Child::wait(&mut self)` blocks and must not run on the main thread.
    /// What stays here is the signal handle `ChildKiller::clone_killer()`
    /// returns — that is exactly what it exists for.
    killer: Box<dyn portable_pty::ChildKiller + Send + Sync>,

    /// Set by the reader thread when the child's output stream ends.
    pub exited: Arc<AtomicBool>,
    /// The exit status, once reaped. `None` while running.
    /// `ExitStatus::exit_code()` is a `u32` and `signal()` an `Option<&str>`;
    /// keep the whole struct rather than flattening it, so a signalled child
    /// can be reported as such.
    pub exit: Arc<Mutex<Option<portable_pty::ExitStatus>>>,
    /// Last `(cols, rows)` pushed to the PTY, so resize is issued only on change.
    pub size: Cell<(u16, u16)>,
}
```

`SessionTable` is a `RefCell<BTreeMap<SessionId, Session>>` inside
`PtyExtension`, plus an `Arc<RwLock<Vec<SessionSummary>>>` shared with
`PtyProvider` (the provider runs on the async task thread and must not touch
the `RefCell`). `SessionSummary` is a plain `{ id, label, origin_kind, running,
exit_label }` snapshot (`exit_label` already rendered, e.g. `"exit 1"` /
`"signal SIGTERM"`) refreshed whenever the table changes — this mirrors how
`BookmarksProvider` shares an `Arc<RwLock<Vec<PathBuf>>>` with its extension.

**Attached session.** At most one session is displayed at a time:
`attached: Cell<Option<SessionId>>`. Attaching means:

1. `Intent::SetFunctionForm(Some("pty"))` — claims the panel and moves focus.
2. `Intent::SetInputCapture(Some(InputCapture { owner: "pty", release: prefix_key, escape: session.escape.intents() }))`.

Detaching is the exact inverse (`SetFunctionForm(None)`,
`SetInputCapture(None)`) — though when core released the capture itself (an
escape intent or the prefix key), the extension only needs to emit
`SetFunctionForm(None)`. The session keeps running and its output keeps
accumulating in its `vt100::Parser`; only the display is dropped.

### Spawning

```rust
use portable_pty::{native_pty_system, CommandBuilder, PtySize};

let sys = native_pty_system();
let pair = sys.openpty(PtySize { rows, cols, pixel_width: 0, pixel_height: 0 })?;
let mut cmd = CommandBuilder::new(&argv[0]);
cmd.args(&argv[1..]);
cmd.cwd(&cwd);
cmd.env("TERM", "xterm-256color");
let child = pair.slave.spawn_command(cmd)?;   // Box<dyn Child + Send + Sync>
drop(pair.slave);                             // must drop, or EOF never arrives
let killer = child.clone_killer();
let mut reader = pair.master.try_clone_reader()?;
let writer = pair.master.take_writer()?;      // valid exactly once per master
let master = pair.master;
// `child` is moved into the reader thread below; `killer`, `writer` and
// `master` stay in the Session on the main thread.
```

`TERM=xterm-256color` is deliberate: vt100 0.16 implements the xterm subset.
Do not advertise `xterm-kitty` — we do not implement the graphics protocol.

### Reader thread

One thread per session:

```rust
std::thread::spawn(move || {
    let mut buf = [0u8; 8192];
    loop {
        match reader.read(&mut buf) {
            Ok(0) | Err(_) => break,
            Ok(n) => {
                kbmode.lock().unwrap().feed(&buf[..n]);   // §5.3
                parser.lock().unwrap().process(&buf[..n]);
                // Coalesce: only wake the loop if it is not already awake.
                if !dirty.swap(true, Ordering::AcqRel) {
                    let _ = tx.send(AppEvent::Tick);
                }
            }
        }
    }
    // The read loop ends when the child closes its end, so `wait` returns
    // immediately here. It blocks, which is why the child was moved into this
    // thread rather than kept in the Session.
    if let Ok(status) = child.wait() {
        *exit.lock().unwrap() = Some(status);
    }
    exited.store(true, Ordering::Release);
    let _ = tx.send(AppEvent::Tick);
});
```

The `dirty: Arc<AtomicBool>` is cleared by `render_form`. Without it, a chatty
child (`yes`, a build log) floods the channel with one `Tick` per 8 KB read and
the loop starves. With it, at most one wake-up is outstanding at a time, so the
repaint rate self-limits to the render rate.

**Reaping.** `child.wait()` blocks, so it must not run on the main thread. The
reader thread calls it after the read loop ends and stores the code in
`exit_code`. `PtyExtension` observes `exited` from `on_cursor_changed` — the generic
broadcast core already calls on every extension after each dispatch — and emits
the completion notice, the `@/messages` line, and (for `Origin::Edit`) the
Refresh from there. It must not be done from `render_form`: that returns a
title, not intents, so a notice raised there would have nowhere to go.

---

## 5. Input

### 5.1 The capture contract

While an `InputCapture` naming `pty` is installed, `handle_key` (C4) sends
**every** key that is not one of the two escapes to `PtyExtension::handle_intent`
as `ExtensionIntent { extension: "pty", intent: "key", data: encode_key(key) }`.
That includes `q`, `Ctrl-C`, and the arrow keys.

### 5.2 Escape handling

**All escape logic lives in core (§C4).** The extension does not inspect keys
for escapes, and `handle_intent("key", …)` never has to decide whether to
release — if it was called, the key is the child's. This is what makes the
lockout guarantee real: the extension is not a participant in it.

The extension's two obligations are:

- **`handle_intent("key", …)`** — decode, encode for the child (§5.3), write
  (§5.4). Return no intents.
- **`handle_intent("prefix", …)`** — core has *already* cleared the capture, so
  there is nothing left to do but let the session stay on screen. It opens no
  submenu: an extra key to dismiss one would make the single guaranteed way out
  of a captured keyboard cost two presses.

**Releasing is not closing.** The prefix key, and a child exiting, give back the
*keyboard* and leave the session in the panel. That is what makes the terminal
scroll like every other function-panel frame (§6): the output stays readable,
`k`/`j` walk the scrollback, and `Enter` takes the keyboard back. Closing the
panel outright is a separate action (`pty-detach`, or `pty.close-on-exit`).

`Ctrl-C` is not special. Under capture it encodes to `\x03` and goes to the
child, which is the whole point of a terminal panel. wasdf does not need its
own `Ctrl-C` while attached; `Ctrl-b` is the way out.

Note that `portable-pty` puts the child in its own session on Unix, so a
`Ctrl-C` typed at the *outer* terminal reaches wasdf, not the child — only the
encoded `\x03` reaches the child. That is the correct and intended split.

### 5.2.1 Why `Origin::Edit` uses `PrefixOnly`

An editor needs every letter, `w` and `s` most of all. `Origin::Command` can
afford to give up the six navigation moves because a command CmdOp assembled is a
one-shot whose interaction is at most a `y/n` confirmation; an editor cannot.
So `Edit` escapes on the prefix key alone, exactly like a shell.

### 5.3 Encoding for the child

**Both encodings are in v1.** The child gets CSI-u the moment it asks for it;
there is no "legacy first, Kitty later" phase.

The child decides its own keyboard protocol, and wasdf's own input protocol
(§C2) is irrelevant to that decision — the two are independent negotiations
that happen to use the same escape sequences. `kbmode.rs` tracks the child's
side by sniffing its output byte stream, because `vt100` 0.16 does not model
these sequences:

| Sequence | Meaning |
|----------|---------|
| `CSI > flags u` | push `flags` onto the child's keyboard stack |
| `CSI < n u` | pop `n` entries |
| `CSI = flags ; mode u` | set flags on the current entry |
| `CSI ? u` | query — reply `CSI ? flags u` **into the child's input** |

`kbmode::Stack` is a `Vec<u8>` of flag words with `Stack::current() -> u8`
(0 when empty = legacy). Implement `feed(&[u8])` as a small state machine over
`ESC [` … final byte `u`; anything else is passed over. It never modifies the
stream — `vt100` still sees the full bytes.

`encode.rs` then has exactly two paths:

```rust
/// The bytes to write to the child for `key`, given the child's current
/// keyboard flags. `flags == 0` selects the legacy encoding.
pub fn encode(key: Key, flags: u8) -> Vec<u8>;
```

**Legacy path** (`flags == 0`) — the xterm encoding every TUI understands:

| Key | Bytes |
|-----|-------|
| `Char(c)`, no mods | UTF-8 of `c` |
| `Char(c)` + ctrl, `c` in `@A-Z[\]^_` or `a-z` | `c as u8 & 0x1f` |
| `Char(c)` + alt | `ESC` then the above |
| `Enter` | `\r` (**not** `\n`) |
| `Tab` / `BackTab` | `\t` / `ESC [ Z` |
| `Backspace` | `\x7f` |
| `Esc` | `\x1b` |
| `Up`/`Down`/`Right`/`Left` | `ESC [ A/B/C/D`, or `ESC [ 1 ; <m> A` etc. when modified |
| `Home`/`End` | `ESC [ H` / `ESC [ F` |
| `Insert`/`Delete`/`PageUp`/`PageDown` | `ESC [ 2~` / `3~` / `5~` / `6~` |
| `F(1..=4)` | `ESC O P/Q/R/S` |
| `F(5..=12)` | `ESC [ 15~ 17~ 18~ 19~ 20~ 21~ 23~ 24~` |
| `KeyKind::Repeat` | same as `Press` |
| `KeyKind::Release` | **nothing** (legacy terminals have no release events) |

The xterm modifier parameter is `1 + shift(1) + alt(2) + ctrl(4) + meta(8)`.

**Kitty path** (`flags != 0`) — CSI-u per the
[Kitty keyboard protocol](https://sw.kovidgoyal.net/kitty/keyboard-protocol/):

```
CSI <unicode-key-code> [ : <alternate> ] [ ; <modifiers> [ : <event-type> ] ] u
```

- modifiers = `1 + shift(1) + alt(2) + ctrl(4) + super(8) + hyper(16) + meta(32)`
  (caps-lock 64 and num-lock 128 are not tracked by core `Mods`; always 0)
- event-type = `1` press, `2` repeat, `3` release; emitted only when the child
  set `REPORT_EVENT_TYPES` (bit 0b10)
- functional keys use their CSI-u numbers (`Enter` 13, `Tab` 9, `Backspace`
  127, `Esc` 27, `Insert` 2, `Delete` 3, `Left` 57417 … or the legacy `ESC [ D`
  form when `DISAMBIGUATE_ESCAPE_CODES` alone is set)

**Only emit a release event when the child asked for it.** Sending release
events to a child that did not set `REPORT_EVENT_TYPES` doubles every keystroke.

**The prefix key is never encoded, under either path.** Core consumes it before
the extension sees it (§C4), so no child in any session class can receive it —
that is the price of the lockout guarantee, and it is deliberate. Two ways out
for a child that genuinely needs the key (`Ctrl-b` is `vim`'s page-up):
rebind `pty.prefix-key`, or press the prefix twice — the prefix mode's
`send-prefix` command re-attaches and writes exactly one encoded press (§5.5).

### 5.4 Writing

`handle_intent` writes the encoded bytes directly:

```rust
let _ = session.writer.write_all(&bytes);
let _ = session.writer.flush();
```

This is synchronous I/O inside a synchronous extension call, which
ARCHITECTURE.md's sync/async table does not sanction. It is accepted here for
one reason and documented as an exception: a write to a PTY master is a
non-blocking write to a kernel pipe buffer. If it ever does block (the child
has stopped reading and the buffer is full), the write is **dropped, not
retried** — same failure posture as everywhere else. Never spin.

### 5.5 Session management

There is no prefix submenu. The release key detaches and that is all it does
(§5.2), so the remaining session operations are palette commands — an existing
mechanism that costs no new mode, no new keymap scope, and no extra keystroke
on the path out of a capture:

| Command | Action |
|---------|--------|
| `pty-detach` | give the panel back; the session keeps running |
| `pty-next` / `pty-prev` | attach the next / previous session in id order |
| `pty-kill` | kill the attached child |

Sessions are reached with:

| Key | Scope | Action |
|-----|-------|--------|
| `x` | file / function panel | Attach to the shell already open, or start one if there is none |
| `X` | file / function panel | Always start another shell |
| `e` | file panel | The editor on the file under the cursor (`pty.edit-host`) |
| `h` / `l` | function panel, released | Step left / right through the open sessions |
| `j` / `k` | function panel, released | Scroll the terminal (core's own bindings) |
| `w` `a` `s` `d` | either | Move the file cursor — which gives the panel back to the preview |

`x` is the shell key alone: core's palette binding on it was removed, since the
palette already answers to `z`. Stepping with `h`/`l` *shows* a session without
grabbing the keyboard, since browsing terminals should not cost an escape per
step; `x` is what resumes typing in one.

Moving the file cursor while a session is on screen but released closes the
panel, so the preview follows the cursor exactly as it would have if no session
had ever been open (§C9 is what makes that land on the first keystroke).

**The prefix key is never forwarded to a child.** That is the price of the
lockout guarantee and it is deliberate; rebind `pty.prefix-key` if a child needs
that key.

---

## 6. Rendering

```rust
fn render_form(&self, frame: &mut Frame, inner: Rect, ctx: &FunctionRenderCtx) -> Option<String> {
    let id = self.attached.get()?;
    let table = self.sessions.borrow();
    let s = table.get(&id)?;

    self.resize_if_needed(s, inner);        // §7
    s.dirty.store(false, Ordering::Release);

    let parser = s.parser.lock().ok()?;
    let term = PseudoTerminal::new(parser.screen())
        .cursor(Cursor::default().visibility(ctx.focused));
    frame.render_widget(&term, inner);

    Some(self.title(s))                     // e.g. "pty 3: zsh" / "pty 4: rg foo (exit 1)"
}
```

Core wraps the border, title and open-bottom chrome; the interior is entirely
the extension's. `PseudoTerminal` paints every cell including the background,
so the panel does not need clearing first.

**No `PanelView`.** `view()` returns `None` for the pty extension — a terminal
grid is pre-styled cells, which is exactly what the logical `PanelView`
vocabulary refuses to carry. `render_form` is the sanctioned bundled-only
escape and this is precisely its intended use.

**Scrollback.** `form_scroll` (§C8) reports `(scrollback + rows, position)`, so
the panel draws the same scrollbar as any other frame and core clamps the scroll
for us. Core counts rows from the top of the content and vt100 counts rows back
from the live screen, so `Session::scroll_to` inverts between them — without
that, `k` and `j` would mean the opposite of what they mean over a document.
New output pushes the view back to the live tail (`Intent::SetScroll`), the way
a terminal behaves.

**Search.** `/` search over a terminal screen is not supported in v1.
`content_lines()` returns 0 and the extension handles no search intents. (Under
capture, `/` goes to the child anyway.)

---

## 7. Resize

The panel's inner rect is known only at render time — the same problem the
markdown previewer solved with a cached viewport. Reuse the pattern:

```rust
fn resize_if_needed(&self, s: &Session, inner: Rect) {
    let want = (inner.width.max(1), inner.height.max(1));
    if s.size.get() == want { return; }
    s.size.set(want);
    let _ = s.master.resize(PtySize {
        rows: want.1, cols: want.0, pixel_width: 0, pixel_height: 0,
    });
    if let Ok(mut p) = s.parser.lock() {
        // Note: `set_size` lives on `Screen`, not `Parser` — go through
        // `screen_mut()`. There is no `Parser::set_size` in vt100 0.16.
        p.screen_mut().set_size(want.1, want.0);
    }
}
```

Order matters: resize the PTY first (so the child gets `SIGWINCH` and redraws
at the new size), then the parser. Both must be told, or the screen and the
child disagree about wrapping.

A detached session is never resized — it keeps the geometry it had when it was
last visible. Re-attaching resizes it on the first `render_form`.

---

## 8. `@/pty` — the session tree

`PtyProvider` implements `VfsProvider` with `mount() == "pty"`. Virtual paths
are lowercase (`@/pty/...`); the VFS root listing capitalizes display names on
its own, so the user sees **PTY** next to FILESYSTEM / BOOKMARKS / SETTINGS.

```
@/pty/                        one directory per live session
@/pty/<id>/                   e.g. @/pty/3
@/pty/<id>/console            leaf, activation = attach
```

`@/pty/<id>` is a **directory** even though it holds one leaf today. That is
deliberate: it reserves the shape for the child-process listing (`@/pty/<id>/
<pid>`) without a future path change.

Session directory names are `<id>`; the *display* name is
`"<id>: <label>"` (`zsh`, `rg foo`, `vim README.md`), suffixed `" (exit N)"`
once the child has exited.

`console`'s activation is the standard leaf pattern:

```rust
e.activation = Some(ExtensionIntent {
    extension: "pty".into(),
    intent: "attach".into(),
    data: ExtensionValue::Int(id as i64),
});
```

`PtyProvider::list` reads the shared `Arc<RwLock<Vec<SessionSummary>>>` only —
it runs on the async task thread and must stay cheap (`VfsProvider`'s contract:
"Keep `list` cheap (in-memory); it runs on every nav-panel render").

**Exited sessions stay listed** until the user removes them, so a command's
console output is inspectable after the fact. `pty.keep-exited` (§9) bounds how
many; the oldest exited session is dropped past the cap.

---

### 8.1 Handing the shell a directory

Resuming a shell with `x` pastes the **directory holding whatever the file
cursor points at** into its prompt — the entry's *parent*, so a cursor on
`/a/b/c.txt` gives `/a/b` and one on the directory `/a/b/d` also gives `/a/b`.

The cursor's entry, not the file panel's `cwd`: after `f` the cursor can be
sitting on a match from somewhere else entirely, and that match's own directory
is the useful answer.

It is **pasted, not run**. Nothing executes, no history line is written, and no
shell-specific quoting or command name is needed — the user decides what the
path is for. Where the child supports bracketed paste the text is wrapped in
`ESC[200~` … `ESC[201~`, so even an embedded newline could not run it.

A virtual location (`@/settings`) offers nothing; no shell can use it.

### 8.2 Knowing the shell is at its prompt

Pasting into a *running* command would feed it stdin, so the paste is gated on
[`Session::at_prompt`], which reads two signals because neither alone covers the
shells people use:

| Signal | Covers | How |
|--------|--------|-----|
| **Bracketed paste** (DEC mode 2004) | zsh, fish, nushell | A line editor turns it on while reading a line and off while the command runs, so its state answers the question directly |
| **The tty's foreground process group** | bash 3.2, dash | Fallback for a child that never mentions 2004 — no line editor, or one predating the mode |

The fallback cannot be the primary, and this is measured rather than assumed:
**zsh leaves job control off** when spawned this way, so its foreground group
never moves and the test would always answer "at a prompt". With `setopt
monitor` forced on it does move — but nothing forces it.

Unknown answers as "not at a prompt": silently doing nothing is a better failure
than typing into a running program.

**There is no standard for the other direction.** OSC 7 (cwd) and OSC 133
(prompt state) are established, widely-implemented ways for a shell to *report*
to its terminal, and kitty, WezTerm, iTerm2, foot and Ghostty all consume them —
but no terminal protocol, kitty's included, can *set* a shell's directory. That
is why this pastes text instead: pushing a `cd` would mean typing a command on
the user's behalf, with per-shell quoting, a per-shell line-kill key, per-shell
history suppression, and no effect at all on nushell, whose `cd` never
`chdir(2)`s the process.

---

## 9. Options

`option_scheme()` returns `include_str!("options.scm")`. Every key is tagged
with the extension id automatically and appears under
`@/settings/Extensions/pty`.

```scheme
;; PTY extension options.
(quote (
  (option "pty.prefix-key"    "Pty" text                                "Ctrl-b" "prefix-key")
  (option "pty.shell"         "Pty" text                                ""       "shell")
  (option "pty.scrollback"    "Pty" (int 0 100000)                      "2000"   "scrollback")
  (option "pty.max-sessions"  "Pty" (int 1 64)                          "8"      "max-sessions")
  (option "pty.keep-exited"   "Pty" (int 0 32)                          "4"      "keep-exited")
  (option "pty.cmdop-host"    "Pty" bool                                "#t"     "run CmdOp commands on a PTY")
  (option "pty.edit-host"     "Pty" bool                                "#t"     "run the editor on a PTY")
  (option "pty.close-on-exit" "Pty" (choice "never" "success" "always") "never"  "close-on-exit")))
```

`bool` / `text` / `list` are bare symbols; only `int` and `choice` take a list
form. `(text)` is rejected at load with an `@/messages` line.

```scheme
```

- **`pty.prefix-key`** becomes `InputCapture::release` — the key core honours
  unconditionally (§C4), and therefore the one key no child can ever receive.
  It is parsed with the existing `script::codec::parse_key`. A value that does
  not parse, or that carries no ctrl modifier, is rejected at load with a
  `@/messages` line and the default is used; requiring ctrl is what keeps a
  bare letter from becoming unsendable. Whatever it is set to, **no child can
  ever receive it** — it is the one key wasdf keeps. `C-b` collides with
  `vim`'s page-up, so a user who turns on `pty.edit-host` will likely want to
  move it.
- **`pty.shell`** empty means: `$SHELL` on Unix, `%COMSPEC%` on Windows. See
  §12. A session starts in the file panel's directory when that is a real one,
  and in the home directory when it is virtual (`@/settings`, `@/pty`) — no
  process can chdir into a VFS path.
- **`pty.scrollback`** is `vt100::Parser::new`'s third argument.
- **`pty.close-on-exit`** — whether the *panel* also goes when the child exits.
  The keyboard always comes back regardless (a dead child cannot use it), so
  `never` (the default) leaves the final output on screen and scrollable, which
  is usually what you want after a command finishes. `always` clears the panel
  too; `success` clears it only on exit code 0.

Read them through the `Arc<OptionStore>` stashed in `bind_store`, exactly as
`PreviewExtension` does with `preview.tab-width`.

---

## 10. CmdOp integration

Today, `CmdOpExtension`'s builder ends at
`vec![Intent::Execute { argv }, Intent::SetFunctionForm(None)]`
(`cmdop/extension.rs`, the `"builder-edit"` input purpose), and `Plan::Execute`
streams stdout line-by-line into the Exec frame.

With `pty.cmdop-host` on, that becomes a `pty` extension intent:

```rust
vec![
    Intent::Extension(ExtensionIntent {
        extension: "pty".into(),
        intent: "run".into(),
        data: ExtensionValue::Map(btreemap! {
            "argv"   => ExtensionValue::List(argv.iter().map(|s| ExtensionValue::String(s.clone())).collect()),
            "cwd"    => ExtensionValue::Path(cwd),
            "label"  => ExtensionValue::String(display_line),
            "escape" => ExtensionValue::String("prefix-and-cursor".into()),
        }),
    }),
    Intent::SetFunctionForm(None),
]
```

**CmdOp must not name `pty` unconditionally.** Doing so would make the two
extensions mutually dependent and break the zero-edit posture in the other
direction. Instead:

- CmdOp reads `pty.cmdop-host` from the option store it already holds.
- When false (or the option is absent, i.e. the pty extension is not
  registered), CmdOp emits `Intent::Execute { argv }` exactly as today.

That keeps the fallback honest: with the pty extension removed from
`bundled()`, CmdOp still works.

### What `"run"` does

1. Spawn a session with `Origin::Command { label }`,
   `EscapeClass::PrefixAndCursor`.
2. Attach it (§4): `SetFunctionForm` + `SetInputCapture` with `escape =
   [CursorUp, CursorDown, CursorLeft, CursorRight, CursorTop, CursorBottom]`.
3. `PANEL_FUNCTION` now shows the child's live screen; the user can type into
   it (it is a real PTY, so a prompt from `rm -i` or a `git` credential query
   works — `y`/`n` and the whole alphabet except the movement keys reach the
   child).
4. Any key the keymap resolves to one of the six navigation intents detaches:
   core clears the capture and dispatches the move, so the file cursor actually
   moves on that same keystroke. Because the escape is declared as intents,
   this is `w`/`a`/`s`/`d` (plus whatever is bound to top/bottom) by default
   and follows the user's keymap if they rebind it. The session keeps running.
5. On exit, the extension emits `Intent::Notify(...)` with the same shape the
   resolver's `OpDone` notice uses ("`<label>`: ok" / "`<label>`: exit 1"), and
   pushes the same line to `@/messages`. **The completion report is unchanged
   from today's behaviour** — only the console moved.
6. The console remains at `@/pty/<id>/console` until evicted by
   `pty.keep-exited`.

---

## 11. Edit integration

`Intent::Edit { path }` currently reduces to `Plan::Suspend { argv: [editor,
path] }`, which leaves the alternate screen entirely (`terminal::run_suspended`).

With `pty.edit-host` on, `StartEdit` instead emits the same `"run"` intent with
`Origin::Edit { path }`, **`EscapeClass::PrefixOnly`**, and issues
`Intent::Refresh` when the child exits (so a saved file's new mtime/size shows
up) — matching what the Suspend path already does.

`PrefixOnly` is the whole reason an editor is viable here: `w`, `a`, `s` and
`d` reach `vim` like every other letter, and the prefix key is the only key
wasdf takes.

That one key is taken unconditionally. `Ctrl-b` is also `vim`'s page-up, and
the prefix wins — a user who edits in the panel should rebind
`pty.prefix-key` to something the editor does not want, or reach page-up with
the double-press (`send-prefix`, §5.5).

**The default is on (`#t`)**: `e` opens the editor in the panel, and the file
panel stays visible beside it. Turning the option off restores core's suspend,
which hands the editor the whole terminal — worth doing if the panel is too
narrow for comfortable editing.

The same conditional-emission rule as CmdOp applies: the reducer's
`Intent::Edit` arm must not name `pty`. Because the reducer is pure and cannot
read an extension's options, this is implemented in the **pty extension's
`on_cursor_changed`-free path** instead: the extension contributes a keymap
binding at the Extension layer that overrides core's `e` → `StartEdit` with
`(ext "pty" "edit")`, gated on a `:when` condition the extension registers
(`pty-edit-host`). Layer priority (Core < Extension < User) makes the override
work with zero core edits, and a user binding still wins over both.

---

## 12. Windows

- `portable-pty` uses **ConPTY** on Windows (`src/win/conpty.rs`), which needs
  Windows 10 1809+. Its winpty fallback needs an external `winpty-agent.exe`;
  do not depend on it. If `openpty` fails, follow the project rule — notify,
  and let the caller fall back (CmdOp to `Intent::Execute`, Edit to
  `Plan::Suspend`).
- **uutils does not provide a shell.** `uutils/coreutils` gives cross-platform
  `ls` / `cat` / `cp`, which is what the *resolver* needs, but a terminal panel
  needs a shell to run. `pty.shell` therefore defaults per platform:
  `$SHELL` → `/bin/sh` on Unix, `%COMSPEC%` → `cmd.exe` on Windows. A user who
  wants one shell everywhere can point it at `nu` or `pwsh`.
- Windows terminals do not implement the Kitty keyboard protocol. C2's
  `supports_keyboard_enhancement()` guard returns false there and everything
  degrades to the legacy encoding, which is the correct behaviour — do not
  special-case the platform.
- `CommandBuilder::new` on Windows resolves through `PATH` with `.exe`
  appended; pass a bare `"cmd"`, not `"cmd.exe"`.

---

## 13. Failure policy

Uniform with the rest of the project: **disable, notify, continue.**

| Failure | Behaviour |
|---------|-----------|
| `openpty` fails | notice + `@/messages`; no session; caller falls back |
| `spawn_command` fails | same, plus the PTY is closed |
| reader thread read error | treat as EOF: mark exited, wake once |
| `writer.write_all` fails | drop the keystroke; mark the session exited if the error is `BrokenPipe` |
| a lock is poisoned | detach and mark the session dead; never `unwrap` a lock in `render_form` |
| `pty.prefix-key` unparseable | `@/messages` line, use `C-b` |
| session cap reached | notice; refuse the spawn, do not evict a running session |

**A dead session should release capture, but nothing depends on it doing so.**
The tidy path is in `render_form` and `handle_intent("key", …)`: if the
attached session is missing or exited *and* `pty.close-on-exit` says to close,
emit `SetInputCapture(None)` + `SetFunctionForm(None)`. If that path is never
reached — the extension panicked, a lock is poisoned, the session vanished —
the prefix key still frees the user, because core honours it without consulting
the extension (§C4). That is the difference between a convention and a
guarantee, and it is why the release key lives in core.

---

## 14. Dependencies

```toml
# A pseudo-terminal for the `pty` extension. portable-pty is the only crate
# that abstracts Unix openpty and Windows ConPTY behind one API; vt100 is the
# screen model; tui-term blits that model into a ratatui Buffer and is already
# on ratatui-core 0.1.x (ratatui 0.30), unlike most widget crates.
portable-pty = "0.9"
vt100 = "0.16"
tui-term = "0.3"
```

Verified with `cargo add -p wasdf --dry-run`: `ratatui-core` unifies at 0.1.2
(up from the current 0.1.1, semver-compatible), `vt100` resolves to a single
0.16.2, and no second `ratatui` appears.

`tui-term`'s `Screen` / `Cell` traits abstract the backend, so `vt100` can
later be swapped for `wezterm-term` or `alacritty_terminal` without touching
`render_form`. Do not take that dependency now: `wezterm-term` has no
first-party crates.io release.

---

## 15. Test plan

Unit (no PTY, no terminal):

- `encode.rs`, legacy path — every row of the legacy table; the xterm modifier
  parameter (`1 + shift + 2·alt + 4·ctrl + 8·meta`); ctrl-letter folding
  (`Ctrl-a` → `0x01`, `Ctrl-@` → `0x00`); alt-prefixing; `Enter` is `\r` and
  never `\n`; `Release` produces **nothing** at `flags == 0`.
- `encode.rs`, Kitty path — the modifier parameter uses the *Kitty* weights
  (`1 + shift + 2·alt + 4·ctrl + 8·super + 16·hyper + 32·meta`), which differ
  from xterm's above and are the easiest thing in this document to get wrong;
  the event-type suffix appears only when `REPORT_EVENT_TYPES` is set and is
  `1`/`2`/`3` for press/repeat/release; functional keys use their CSI-u numbers
  under `REPORT_ALL_KEYS_AS_ESCAPE_CODES` but the legacy `ESC [ D` form under
  `DISAMBIGUATE_ESCAPE_CODES` alone; a plain unmodified `a` stays a bare `a`
  unless all-keys mode is on.
- `encode.rs`, both — the same `Key` through `flags == 0` and `flags != 0`
  produces different bytes for a modified key and identical bytes for a plain
  printable one. This is the property that catches a mis-wired `flags`.
- `kbmode.rs` — `CSI > 5 u` pushes, `CSI < 1 u` pops, `CSI = 3 ; 1 u` sets,
  `CSI ? u` is answered into the child's input; a sequence **split across two
  `feed` calls** is still recognised (the reader delivers 8 KB chunks with no
  regard for sequence boundaries, so this is the realistic case, not the edge
  case); a non-keyboard CSI (`CSI 2 J`) leaves the stack alone; `feed` never
  alters the bytes `vt100` subsequently sees.
- `provider.rs` — the `@/pty` listing shape, the `console` activation intent
  (mirror `bookmarks/provider.rs`'s test).
- `EscapeClass::intents()` — `PrefixOnly` is empty; `PrefixAndCursor` is
  exactly the six navigation intents, and in particular does **not** contain
  `Activate`.
- `Key` codec — `encode_key` / `decode_key` round-trip over every `KeyCode`,
  every modifier combination, and all three `KeyKind`s.

Integration (spawn a real PTY; skip on Windows CI if ConPTY is unavailable):

- spawn `printf hello`, wait for exit, assert the vt100 screen's first row
  reads `hello` and the recorded `ExitStatus::success()` is true.
- spawn `cat`, write `"hi\r"`, assert the screen echoes it.
- resize a session and assert `parser.screen().size()` changed.

Core regressions to guard (all in `app/kernel.rs`'s tests, through the real
`handle_key` path):

- a keymap binding fires **once**, not twice, when release events are enabled.
- with a capture installed, a bound key (`q`) does **not** quit — it reaches
  the owner as `"key"`.
- the `release` key clears `input_capture` **even when the owning extension
  returns nothing** from `"prefix"`. Assert with a stub extension whose
  `handle_intent` returns `Vec::new()`; this is the lockout guarantee and it
  must be tested against an uncooperative extension, not a cooperative one.
- an escape intent clears the capture *and* dispatches the move: press `w`
  under `PrefixAndCursor`, assert both `input_capture.is_none()` and that the
  file cursor advanced by one. Repeat for the top/bottom binding, which must
  both detach and jump.
- under `PrefixOnly`, `w` reaches the owner as `"key"` and the cursor does not
  move.
- `Enter` under `PrefixAndCursor` reaches the owner as `"key"` — `Activate` is
  not an escape.
- with `input_capture` cleared, everything behaves exactly as before.

---

## 16. Decisions

Every question raised against this design has been answered. Nothing here is
open; the table is the record of *why* each shape was chosen, so a later reader
does not re-litigate it.

| # | Question | Decision |
|---|----------|----------|
| D1 | How does a CmdOp session release the keyboard? | On the **intents**, not on the literal keys `w`/`a`/`s`/`d`: core resolves the key through the keymap, so the escape follows whatever the user bound. §C4, §5.2, §10 |
| D2 | Which intents? | All six navigation moves — `CursorUp`, `CursorDown`, `CursorLeft`, `CursorRight`, `CursorTop`, `CursorBottom`. Not `Activate` / `NavigateTo`. §4 |
| D3 | Is losing the movement letters acceptable for a CmdOp child? | Yes. A command the builder assembled interacts at most at the `y`/`n` level. §5.2.1 |
| D4 | How does an `Edit` session release? | `EscapeClass::PrefixOnly` — the prefix key alone, so an editor keeps the whole alphabet. §5.2.1, §11 |
| D5 | Lockout escape hatch | The prefix key is checked by **core**, first, before anything reaches the extension, and clears the capture unconditionally. A wedged extension cannot trap the user. §C4, §13 |
| D6 | `Ctrl-C` while attached | Goes to the child as `\x03`. wasdf does not need its own `Ctrl-C` while attached; the prefix key is the way out. §5.2 |
| D7 | Replaying the escape key | Dissolved. Core clears the capture and dispatches the intent itself, in that order, in one place — there is nothing for the extension to replay and no dispatch-ordering dependency. §C4 |
| D8 | `doc/` vs `docs/` | `doc/`, alongside the four existing specs. |
| D11 | Which key opens a shell? | `x` in the file panel. It collides with core's command palette, which the Extension layer therefore shadows — see the note in §16. |
| D12 | Where does a session start? | The file panel's directory when real; the home directory when virtual. §9 |
| D13 | What happens when a child exits? | The panel is handed back automatically (`pty.close-on-exit` defaults to `always`), for every session class. §9 |
| D14 | What does the prefix key do? | Releases the keyboard, leaving the session on screen and scrollable. No submenu, no second keystroke. Session management moved to palette commands. §5.2, §5.5 |
| D15 | Does the pty panel scroll? | Yes, through the same scrollbar and clamp every other function-panel frame uses (`Extension::form_scroll`). §6, §C8 |
| D16 | Does the file panel follow the child's `cd`? | **No.** The sync ran the other way and was dropped: `cd` cannot be read portably (nushell never `chdir`s), and nothing can set a shell's directory from outside. `x` pastes a path into the prompt instead and leaves the decision to the user. §8.1 |
| D17 | `x` vs `X` | `x` reuses the newest running shell; `X` always spawns. §5.5 |
| D18 | What do `h`/`l` do once released? | Step through open sessions. Horizontally scrolling a terminal is meaningless; stepping through them is not. §5.5 |
| D19 | What happens when the file cursor moves while released? | The panel goes back to the preview. §5.5, §C9 |
| D9 | Kitty passthrough to the child | **In v1.** `kbmode.rs` and both branches of `encode.rs` ship together; the child gets CSI-u whenever it has asked for it. §5.3 |
| D10 | The prefix key collides with a child's own binding (`Ctrl-b` is `vim`'s page-up) | **The prefix always wins.** It is never forwarded, in any session class. A user who needs it in the child either rebinds `pty.prefix-key` or sends one literal press with the prefix-mode `send-prefix` command. §5.3, §5.5, §9 |
