# The Help Row

The bottom row of the screen is a single unboxed line of key hints for the
current mode and focus ([UI.md](UI.md)'s `bottom | help` panel). This document
records what it does today, why that is wrong, and the proposed replacement.

Status: **implemented.** §1–§2 record what it used to do and why that was
wrong; §3 is the design as built; §6 is the decision record.

---

## 1. What it does today

`ui/bottom.rs::hints_for(state)` is a hardcoded `match` over `state.mode()` and
`state.focused_panel`, returning pairs of `&'static str`:

```rust
type Hint = (&'static str, &'static str);   // ("wasd", "move")

fn hints_for(state: &AppState) -> Vec<Hint> {
    match state.mode() {
        Mode::File => { /* … focused_panel == "function" ? … : */
            vec![("wasd","move"), ("Space","select"), ("f","find"), ("z","palette"),
                 ("c","copy"), ("m","move"), ("R","rename"), ("E","edit"),
                 ("@","vfs"), (",","panel"), ("q","quit")] }
        Mode::Select(spec) if spec.id == "command" => …,
        Mode::Select(_) => …,
        Mode::Policy(_) => …,
        Mode::InputForm(_) => …,
        Mode::Extension { .. } => vec![("Esc", "back")],
    }
}
```

`render_bottom(frame, area, state, theme)` does not receive the
`KeymapRegistry` at all (`ui/render.rs`), so **no part of the help row is
derived from the keymap**. Layer priority, scope specificity, and `:when` are
all invisible to it.

`doc/UI.md` says only "Key hints, drawn in reverse video (negative) / kernel
UI". There is no spec for *what* the hints are, so the current behaviour is not
a violation — it is undefined. Fixing this starts by writing the rule down.

## 2. What is wrong with it

**D1 — Extension keys never appear.** The file panel has roughly 30 live
bindings; the help advertises 11. Missing: `x` `X` `e` (pty), `M` (cmdop), `B`
(bookmarks), `/` `n` `p` (preview), and core's own `W` `S` `v` `.` `~` `Ctrl-a`
`r` `Tab` `Delete` `Backspace` `Enter` `k` `j` `h` `l`.

**D2 — Core hardcodes an extension's keys.** `("c","copy") ("m","move")
("R","rename")` are **CmdOp's** bindings. No extension *id* appears, so the
Zero-Edit acceptance test passes on the letter; the spirit does not. Drop
CmdOp from `bundled()` and the help still advertises `c`/`m`/`R`.

**D3 — A hosted form makes the hints actively false.** The function-panel branch
switches on `search.input_active` and `search.matches` but never on
`form_owner`. While a PTY session or the CmdOp builder owns the panel it still
reads `j/k scroll · h/l ◂▸ · / search · n line# · g/G top/bottom · Enter open ·
Esc hide`. Under a captured keyboard *every one of those is wrong* — the keys go
to the child — and the one key that does work, the prefix (`Ctrl-b`), is not
shown. Released, `h`/`l` now step through sessions rather than scrolling.

**D4 — `:when` is ignored.** `f` is a deep search on a real directory and a
shallow filter on a virtual one; the hint says "find" either way. `n`/`p` only
exist while `function-has-matches` holds, and `n` is simultaneously
`toggle-line-numbers` and `function-search-next` depending on it.

**D5 — Extension modes get one generic line.** `Mode::Extension { .. } =>
vec![("Esc","back")]`, whatever the mode actually binds.

The common cause of all five: **the help is a second, hand-maintained copy of
the keymap.** It drifts the moment anything is rebound, and it cannot see
anything an extension contributed.

---

## 3. Proposal: the label lives on the binding

Move the help text onto `Binding`, and derive the row from the keymap that is
actually in force.

```rust
// script/keymap.rs
pub struct Binding {
    pub mode: String,
    pub panel: Option<String>,
    pub key: Key,
    pub intent: Intent,
    pub when: Cond,
    pub layer: Layer,
    /// The help-row label for this binding, e.g. `"copy"`. `None` — the
    /// default — keeps the binding out of the help row entirely.
    ///
    /// Opt-in rather than derived from the intent: the file panel binds about
    /// thirty keys and the row is one line, so *which* to advertise is an
    /// editorial choice. What is not editorial is the key itself, and that now
    /// always comes from the binding that would really fire.
    pub help: Option<String>,
}
```

The key is never written twice, so it can never be stale. The label is the only
authored part, and authoring it is how something opts into the row.

### 3.1 Scheme form

A binding is `("key" intent [when])` today. Add the label as a **string** slot
anywhere after the intent:

```scheme
("c" (ext "cmdop" "start-copy") "copy")
("f" file-search (and (not filter-maxed) (not cwd-virtual)) "find")
("n" function-search-next function-has-matches "match")
```

`when` is always a symbol or a list, a label is always a string, so the two are
distinguished by type rather than by position — every existing binding keeps
parsing unchanged. In `parse_keymap_config`, scan the slots after the intent and
take the first `Datum::Str` as `help`, the first non-string as `when`.

### 3.2 Enumeration reuses `resolve`

The help must show the binding that would *actually fire*, which means honouring
the same mode-stack walk, scope specificity, layer priority and `:when` that
`KeymapRegistry::resolve` already implements. Duplicating that logic is how the
two would drift again, so split `resolve` instead:

```rust
impl KeymapRegistry {
    /// The binding that would fire for `key`, or `None`.
    fn resolve_binding(&self, conds: &Conditions, state: &AppState, panel: &str, key: Key)
        -> Option<&Binding>;

    /// Existing signature, now a thin wrapper.
    pub fn resolve(&self, …) -> Option<Intent> {
        self.resolve_binding(…).map(|b| b.intent.clone())
    }

    /// Every labelled binding in force right now, in registration order, as
    /// `(keys, label)` with keys sharing a label already merged.
    pub fn help_hints(&self, conds: &Conditions, state: &AppState, panel: &str)
        -> Vec<(String, String)>;
}
```

`help_hints` walks the distinct keys of the bindings whose mode scope is on the
stack, calls `resolve_binding` for each, keeps the winners that carry a `help`,
and merges. A key bound twice is therefore advertised once, under whichever
binding won — which is exactly D4's `n`.

### 3.3 Merging and order

- **Merge** bindings that share a label, in registration order. When every
  merged key is a single character the chip concatenates them (`wasd`, `jk`,
  `hl`, `np`, `gG`); otherwise they join with `/` (`Enter/Esc`). Concatenation
  is the house style — `wasd` is the application's own name for its navigation
  and reads as one gesture, not four keys.
- **Order** by registration: Core, then Extension, then User; first appearance
  of a label fixes its position. That reproduces roughly today's ordering for
  the core keys and appends each extension's after them.
- **Overflow**: truncate at the row width. The real lever is that `help` is
  opt-in — an extension labels its headline keys and leaves the rest bare — so
  the row is short by construction rather than by trimming.

### 3.4 Wiring

`render_bottom` gains the registry and the conditions:

```rust
pub fn render_bottom(
    frame: &mut Frame, area: Rect, state: &AppState,
    keymap: &KeymapRegistry, conds: &Conditions, theme: &Theme,
);
```

`ui::render::render` already has neither, so both have to reach it from `App`
alongside `extensions` and `vfs` — the same shape those two already use.

`hints_for` is deleted.

### 3.4.1 Instructional text belongs to the mode

The keyless entries — `("", "type pattern")`, `("", "type to filter")`,
`("", "type argument")` — describe a *mode with an open input*, not a key. They
move onto the mode specs that open those inputs:

```rust
pub struct SelectSpec    { …, pub input_hint: Option<String> }
pub struct InputFormSpec { …, pub input_hint: Option<String> }
```

The mode that opens an input states what the input is for; nothing else has to
know. `render_bottom` prepends the active mode's `input_hint`, when it has one,
as the first (keyless) entry. The function-panel search input, which is not a
mode, keeps its hint in `PanelSearch` on the same principle.

### 3.4.2 A captured keyboard

While an `InputCapture` is installed, `handle_key` bypasses the keymap entirely,
so a keymap-derived row would be empty — worst of all in the one state where the
user most needs to be told the way out. Core therefore renders the row from the
capture itself, which carries exactly the right two things:

```
Ctrl-b release   ·   wasd file cursor
```

- The release chip is `codec::key_name(cap.release)`, so it follows
  `pty.prefix-key` (or whatever any other capturing extension chose) rather than
  being written down anywhere.
- Each intent in `cap.escape` is looked up in the keymap the same way
  `help_hints` does — find the labelled bindings whose intent matches — so the
  escape chips are real keys with their real labels, and follow a rebound
  keymap. An empty `escape` (`EscapeClass::PrefixOnly`) leaves just the release
  chip.

This names no extension and reads no extension state; it is a rendering of a
core type. Everything else on the row is suppressed, because nothing else is
reachable.

### 3.5 What this fixes

| | |
|---|---|
| D1 | An extension's labelled bindings appear because they are in the keymap |
| D2 | `ui/bottom.rs` stops naming `c`/`m`/`R`; CmdOp labels its own bindings |
| D3 | While a form owns the panel its own bindings are what is in scope; a captured keyboard renders from `InputCapture` (§3.4.2), which is the one state where today's row is not merely incomplete but wrong |
| D4 | `:when` is evaluated, so `f`, `n` and `p` say what they currently do |
| D5 | An extension mode shows its own bindings |

---

## 4. Notes from building it

- The `(bind …)` form in a **user** config accepts the label too, by the same
  type rule, so a user can relabel a binding without touching the source. The
  generated `config.scm` template emits it.
- **Merging is by label, so two different things cannot share a word.** The old
  row said `wasd move` *and* `m move`; merged, those became one `wasdm` chip.
  The file cursor is now `cursor` and the operation stays `move`. The same came
  up for the two editors: core's `E` (suspends the whole TUI) is `edit full`,
  the pty-hosted one on `e` is `edit`.
- Chip order is registration order, so bindings are written in the order they
  should read: `w` `a` `s` `d`, not `w` `s` `a` `d`.
- Overflow needs no special handling — a `Paragraph` with no wrap clips at the
  row width, and `help` being opt-in keeps the row short anyway.

## 5. Tests

- `help_hints` returns nothing for an unlabelled keymap.
- A binding whose `:when` is false is absent; the same key with a true `:when`
  is present with the *winning* binding's label.
- Two keys sharing a label merge into one entry, keys joined in registration
  order.
- A key bound in both Core and Extension layers is advertised once, with the
  Extension layer's label.
- A modal mode on the stack stops the walk, so the mode below contributes
  nothing.
- Regression: the File-mode file-panel row reproduces today's hints after
  step 2 of the migration.

---

## 6. Decisions

Every question this proposal raised has been answered; the table is the record
of *why*, so a later reader does not re-litigate it.

| # | Question | Decision |
|---|----------|----------|
| Q1 | `wasd` or `w/a/s/d`? | **`wasd`.** Merged single-character keys concatenate; anything else joins with `/`. A per-label override of the chip text was rejected — it would reintroduce a hand-written key string, the exact thing this design removes. §3.3 |
| Q2 | Where do the keyless instructional entries live? | **On the mode spec.** `SelectSpec` / `InputFormSpec` gain `input_hint`, so the mode that opens an input states what the input is for. §3.4.1 |
| Q3 | What does the row show while the keyboard is captured? | **The capture itself**: the release key (following `pty.prefix-key`, or whatever the capturing extension chose) plus the escape intents resolved back to their real keys and labels. Core renders a core type; no extension is named. §3.4.2 |
| Q4 | Keep `doc/HELP.md`? | **Keep**, indexed from `CLAUDE.md`. The one-line rule also goes into `UI.md` beside the panel catalog when this lands; this file stays as the rationale. |

A consequence of Q1 worth stating plainly: today's hand-written `j/k`, `h/l`,
`n/p` and `g/G` chips become `jk`, `hl`, `np` and `gG`. That is the same rule
that produces `wasd`, and applying it selectively is what would need a special
case.
