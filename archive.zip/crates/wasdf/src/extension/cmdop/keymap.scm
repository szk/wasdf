(quote (
    ;; Entry keys (file panel): open the builder.
    (file file (
        ("c" (ext "cmdop" "start-copy") "copy")
        ("m" (ext "cmdop" "start-move") "move")
        ("R" (ext "cmdop" "start-rename") "rename")
        ("M" (ext "cmdop" "start-create") "create")))
    ;; While the builder hosts the panel (cmdop-active), the function-panel keys
    ;; drive it. wasd still target the file panel (core bindings) so the live
    ;; sources follow the file cursor / marks.
    (file function (
        ("j" (ext "cmdop" "cursor-down") cmdop-active "cursor")
        ("Down" (ext "cmdop" "cursor-down") cmdop-active)
        ("k" (ext "cmdop" "cursor-up") cmdop-active "cursor")
        ("Up" (ext "cmdop" "cursor-up") cmdop-active)
        ("h" (ext "cmdop" "parent") cmdop-active "◂▸")
        ("Left" (ext "cmdop" "parent") cmdop-active)
        ("l" (ext "cmdop" "descend") cmdop-active "◂▸")
        ("Right" (ext "cmdop" "descend") cmdop-active)
        ("Enter" (ext "cmdop" "confirm") cmdop-active "run")
        ("Space" (ext "cmdop" "space") cmdop-active "mark")
        ("/" (ext "cmdop" "filter-start") cmdop-active)
        (";" (ext "cmdop" "section-toggle") cmdop-active)
        ("," cycle-function-panel cmdop-active)
        ("q" (ext "cmdop" "cancel") cmdop-active)
        ("Esc" (ext "cmdop" "cancel") cmdop-active "cancel")))))
