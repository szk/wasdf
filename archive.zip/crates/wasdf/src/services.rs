//! Kernel services: the command registry, the resolver chain, and the matcher
//! backend. Concrete structs configured by data; no registration machinery.

pub mod command;
pub mod matcher;
pub mod messages;
pub mod resolver;

pub use command::CommandRegistry;
pub use matcher::{MatcherBackend, MatcherConfig, RankedEntry, SkimMatcher, rank_paths};
pub use resolver::ResolverChain;
