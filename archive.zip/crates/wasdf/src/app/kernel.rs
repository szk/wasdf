//! The kernel: holds all services and AppState, and runs dispatch_intent — the
//! single pipeline stage that performs extension dispatch, the confirmation
//! gate, and plan issuance + reduction. The event loop calls into it; it
//! contains no intent-specific branches beyond the two structural gates the
//! spec names (extension resolver key, destructive → Policy).

use std::sync::{Arc, Mutex, RwLock};
use std::sync::mpsc::{Receiver, Sender};
use std::time::Duration;

use crate::core::{
    self, AppEvent, AppState, AsyncResult, AsyncStatus, ExtensionIntent, ExtensionValue, InputCapture,
    Intent, Key, KeyCode, Mode, OptionDef, OptionStore, Payload, Plan, Purpose, ResolverRequest,
    KEY_RESOLVER,
};
use crate::extension::{self, Extension, ExtensionRegistry};
use crate::runtime::TaskManager;
use crate::script::codec;
use crate::script::condition::{Cond, Conditions};
use crate::script::keymap::{Binding, KeymapRegistry, Layer};
use crate::services::command::CommandDef;
use crate::services::resolver::ResolverEntry;
use crate::services::{CommandRegistry, MatcherConfig, ResolverChain, SkimMatcher};
use crate::ui::UiManager;

const REDISPATCH_CAP: u32 = 32;

pub struct App {
    pub state: AppState,
    pub keymap: KeymapRegistry,
    pub conditions: Conditions,
    pub commands: CommandRegistry,
    pub resolver: Arc<ResolverChain>,
    pub extensions: ExtensionRegistry,
    pub tasks: TaskManager,
    pub ui: UiManager,
    pub scheme: Arc<crate::script::SchemeSession>,
    /// The unified option store: all options (core + extensions) keyed by name.
    pub store: Arc<OptionStore>,
    pub vfs: Arc<crate::vfs::Vfs>,
    pub rx: Receiver<AppEvent>,
    pub tx: Sender<AppEvent>,
    /// The shared theme registry. `event_loop` reads `resolve_active()` once per
    /// frame; `ThemeExtension` holds a clone for authoring.
    pub theme_registry: Arc<RwLock<crate::extension::theme::ThemeRegistry>>,
    pending_suspend: Option<Vec<String>>,
    /// The last cursor identity broadcast to extensions (target path + panel
    /// visibility), so the cursor-changed event fires only on an actual change.
    last_cursor: (Option<std::path::PathBuf>, bool, usize, String),
    /// The message-log cursor: everything up to this seq has already been
    /// surfaced as a notice by `surface_new_messages` (the only reader).
    /// Captured at boot *start* so boot diagnostics themselves surface.
    msg_seen: u64,
    /// Memo of per-command options parsed from `--help`/`man`.
    option_cache: OptionCache,
}

impl App {
    /// Boot the kernel: build registries, load embedded defaults, register
    /// bundled extensions, and issue the initial directory read.
    pub fn boot(cwd: std::path::PathBuf) -> Self {
        // Before any producer runs, so every diagnostic this boot logs is
        // "new" to surface_new_messages — but nothing from an earlier App in
        // the same process (tests) is.
        let msg_seen = crate::services::messages::global().seq();
        let (tx, rx) = std::sync::mpsc::channel::<AppEvent>();

        // Spawn the resident Scheme session first (pillar #3). Wait briefly for
        // it to be ready: the steel engine loads its stdlib on the dedicated
        // thread and signals readiness. If it is not ready in time, fall back to
        // native defaults so boot never freezes.
        let scheme = crate::script::SchemeSession::spawn();
        let scheme_ready = scheme.wait_ready(Duration::from_secs(3));

        // Keymaps, commands, and resolvers are sourced from embedded Scheme,
        // evaluated by the session (Role 1), or native defaults if not ready.
        let mut keymap = KeymapRegistry::new();
        keymap.extend(if scheme_ready {
            scheme_keymaps(&scheme)
        } else {
            crate::script::keymap::defaults()
        });

        let mut conditions = Conditions::default();

        let mut commands = CommandRegistry::new();
        commands.extend(if scheme_ready {
            scheme_commands(&scheme)
        } else {
            crate::services::command::defaults()
        });

        let mut resolver = ResolverChain::new();
        resolver.extend(if scheme_ready {
            scheme_resolvers(&scheme)
        } else {
            crate::services::resolver::defaults()
        });

        // Build the VFS: the embedded filesystem default, then extensions (each
        // contributes its own mount via `vfs_providers()`). The settings provider
        // is contributed by the settings extension below.
        let mut vfs = crate::vfs::Vfs::default();
        vfs.extend(crate::vfs::defaults());

        // ── OptionStore ────────────────────────────────────────────────────────
        // Collect option defs from core + all extensions before registering, so
        // the store is built once with all defs (first-wins on duplicate keys).
        let bundled_exts = extension::bundled(config_dir());
        let optional_exts = load_optional_extensions();

        let mut all_option_defs = scheme_core_option_defs(&scheme, scheme_ready);
        for ext in &bundled_exts {
            all_option_defs.extend(extension_option_defs(&scheme, scheme_ready, ext.as_ref()));
        }
        for ext in &optional_exts {
            all_option_defs.extend(extension_option_defs(&scheme, scheme_ready, ext.as_ref()));
        }
        let store: Arc<OptionStore> = Arc::new(OptionStore::new(all_option_defs));

        // Build the typed MatcherConfig from store defaults; SettingsExtension
        // and TaskManager share the same Arc so live edits propagate without restart.
        let matcher_cfg: Arc<Mutex<MatcherConfig>> = Arc::new(Mutex::new(MatcherConfig {
            tail_bonus: store.get_i64("matcher.tail-bonus"),
            depth_penalty: store.get_i64("matcher.depth-penalty"),
            length_penalty: store.get_i64("matcher.length-penalty"),
            exec_bonus: store.get_i64("matcher.exec-bonus"),
            preferred_ext: store.get_list("matcher.preferred-ext"),
            noise_ext: store.get_list("matcher.noise-ext"),
            noise_dirs: store.get_list("matcher.noise-dirs"),
            max_results: store.get_u32("matcher.max-results") as usize,
        }));

        // ── ThemeRegistry ──────────────────────────────────────────────────────
        // Parse the bundled presets and build the registry. `ThemeExtension` is
        // constructed before `SettingsExtension` so its `settings_nodes()` can be
        // collected and passed into the settings constructor (plan §11, choice (b)).
        let theme_presets = {
            let datum = crate::script::sexpr::parse(extension::theme::PRESETS_SCHEME)
                .unwrap_or(crate::script::sexpr::Datum::List(vec![]));
            let inner = datum.as_list()
                .and_then(|l| l.get(1))
                .cloned()
                .unwrap_or(crate::script::sexpr::Datum::List(vec![]));
            crate::script::config::parse_theme_config(&inner)
        };
        let theme_registry: Arc<RwLock<extension::theme::ThemeRegistry>> =
            Arc::new(RwLock::new(extension::theme::ThemeRegistry::with_presets(theme_presets)));

        let theme_ext = extension::theme::ThemeExtension::new(
            theme_registry.clone(),
            config_dir().map(|d| d.join("config.scm")),
        );

        // Collect SettingsNode contributions from theme_ext and every bundled
        // extension (e.g. lscolors' Themes, grafted onto its own screen) before
        // building settings_ext (plan §11 choice (b): no interior mutability
        // needed). `&bundled_exts` since the vec is still needed below to
        // register the extensions themselves.
        let settings_nodes: Vec<std::sync::Arc<dyn extension::settings::SettingsNode>> = {
            let mut nodes = theme_ext.settings_nodes();
            for ext in &bundled_exts {
                nodes.extend(ext.settings_nodes());
            }
            nodes
        };

        // The full extension list (id + About) is known only after every extension
        // is registered, so the settings provider reads it through this shared
        // OnceLock, which the kernel fills at the end of construction.
        let ext_infos: extension::settings::ExtInfos = Arc::new(std::sync::OnceLock::new());

        let settings_ext = extension::settings::SettingsExtension::new(
            store.clone(),
            matcher_cfg.clone(),
            settings_nodes,
            config_dir().map(|d| d.join("config.scm")),
            ext_infos.clone(),
        );

        // Register bundled extensions: keymaps, commands, resolver entries,
        // conditions. The only place bundled extensions are named is the facade.
        let mut extensions = ExtensionRegistry::new();
        for ext in bundled_exts {
            keymap.extend(ext.keymaps());
            keymap.extend(extension_scheme_keymaps(&scheme, scheme_ready, ext.as_ref()));
            commands.extend(ext.commands());
            resolver.extend(ext.resolver_entries());
            vfs.extend(ext.vfs_providers());
            ext.register_conditions(&mut conditions);
            extensions.register(ext);
        }
        // Settings and theme registered separately (they need shared Arcs built
        // above). Settings is registered before optional extensions so its ID
        // wins any collision from an optional extension with the same name.
        // Theme still needs the same keymap/command/resolver/condition wiring
        // the bundled_exts loop above gives every other bundled extension.
        vfs.extend(settings_ext.vfs_providers());
        // @/messages: the diagnostic log every messages::log call above and
        // below has been writing into (a kernel service, not an extension —
        // its producers include the loader and this very boot sequence).
        vfs.extend([Box::new(crate::services::messages::MessagesProvider::new(
            crate::services::messages::global().clone(),
            store.clone(),
        )) as Box<dyn crate::vfs::VfsProvider>]);
        extensions.register(Box::new(settings_ext));
        keymap.extend(theme_ext.keymaps());
        keymap.extend(extension_scheme_keymaps(&scheme, scheme_ready, &theme_ext));
        commands.extend(theme_ext.commands());
        resolver.extend(theme_ext.resolver_entries());
        theme_ext.register_conditions(&mut conditions);
        extensions.register(Box::new(theme_ext));

        // Optional (dynamically loaded) extensions: in file-name order; an id
        // collision disables the later one.
        let mut ext_ids: std::collections::HashSet<String> =
            extensions.iter().map(|e| e.id().to_string()).collect();
        for ext in optional_exts {
            if !ext_ids.insert(ext.id().to_string()) {
                crate::services::messages::log(format!("optional extension id collides ({}); disabled", ext.id()), true);
                continue;
            }
            keymap.extend(ext.keymaps());
            keymap.extend(extension_scheme_keymaps(&scheme, scheme_ready, ext.as_ref()));
            commands.extend(ext.commands());
            resolver.extend(ext.resolver_entries());
            vfs.extend(ext.vfs_providers());
            ext.register_conditions(&mut conditions);
            extensions.register(ext);
        }

        // Give every extension the store so they can read their own options,
        // and a way to wake the loop for those that own an I/O source of their
        // own (a PTY reader thread has nobody else to announce it).
        for ext in extensions.iter() {
            ext.bind_store(&store);
            ext.bind_events(tx.clone());
        }

        // Publish the full extension list (id + About) to the settings provider so
        // @/settings/Extensions can list every extension and its About card.
        let _ = ext_infos.set(
            extensions
                .iter()
                .map(|e| extension::settings::ExtInfo { id: e.id().to_string(), about: e.about() })
                .collect(),
        );

        // User layer last: apply to store (warns on invalid values for known keys);
        // then project any matcher.* changes into the shared MatcherConfig.
        if scheme_ready {
            let (user_binds, user_opts) = scheme_user_config(&scheme, &store);
            keymap.extend(user_binds);
            for (k, v) in &user_opts {
                apply_option(&store, k, v);
            }
            project_matcher(&store, &matcher_cfg);
        }
        // Apply the message-log cap now that the user's value (if any) is in
        // the store; MessagesProvider re-reads it on every @/messages listing,
        // so later edits under @/settings/System apply live too.
        crate::services::messages::global()
            .set_max_lines(store.get_u32("max-message-line") as usize);

        for w in keymap.warnings() {
            crate::services::messages::log(format!("warning: {w}"), true);
        }

        let resolver = Arc::new(resolver);
        // Hand the resolver chain to extensions that build external command lines
        // (the CmdOp builder) now that it is finalized and shareable.
        for ext in extensions.iter() {
            ext.bind_services(&resolver);
        }
        let vfs = Arc::new(vfs);
        let matcher: Arc<dyn crate::services::MatcherBackend> = Arc::new(SkimMatcher::default());
        let tasks = TaskManager::new(
            tx.clone(),
            resolver.clone(),
            matcher,
            Some(scheme.clone()),
            vfs.clone(),
            matcher_cfg.clone(),
        );

        let state = AppState::new(cwd.clone());
        let ui = UiManager::new();

        let mut app = App {
            state,
            keymap,
            conditions,
            commands,
            resolver,
            extensions,
            tasks,
            ui,
            scheme,
            store,
            vfs,
            rx,
            tx,
            theme_registry,
            pending_suspend: None,
            last_cursor: (None, false, 0, String::new()),
            msg_seen,
            option_cache: std::cell::RefCell::new(std::collections::HashMap::new()),
        };
        // Initial listing.
        app.spawn_plan(Plan::ReadDir { path: cwd, show_hidden: false });
        app
    }

    /// Handle one key: resolve to an intent, or deliver a RawKeyEvent in
    /// Select / InputForm (the popup text-entry dialog).
    pub fn handle_key(&mut self, key: Key) {
        if let Some(cap) = self.state.input_capture.clone() {
            self.handle_captured_key(&cap, key);
            self.broadcast_cursor_changed();
            return;
        }
        // While the function-panel search input is open, keys edit the query — except
        // Enter (submit) and Esc (cancel), which still resolve via the keymap.
        if self.state.function.search.input_active
            && !matches!(key.code, KeyCode::Enter | KeyCode::Esc)
        {
            self.dispatch(Intent::RawKeyEvent(key));
            self.broadcast_cursor_changed();
            return;
        }
        // While a generic function-panel input is open (any form extension), or a
        // CmdOp text input (filter / prompt / builder edit) is active, all keys are
        // fed as raw events so text editing works. The reducer routes Enter/Esc.
        if self.state.function.input.is_some() {
            self.dispatch(Intent::RawKeyEvent(key));
            self.broadcast_cursor_changed();
            return;
        }
        let panel = self.state.focused_panel.clone();
        match self.keymap.resolve(&self.conditions, &self.state, &panel, key) {
            Some(intent) => self.dispatch(intent),
            None => {
                if matches!(self.state.mode(), Mode::Select(_) | Mode::InputForm(_)) {
                    self.dispatch(Intent::RawKeyEvent(key));
                }
            }
        }
        self.broadcast_cursor_changed();
    }

    /// One key while an [`InputCapture`] is installed. The keymap is bypassed
    /// for everything except the two escapes core itself owns, so a terminal
    /// (or anything else driving a child keystroke-by-keystroke) sees `q`,
    /// `Ctrl-C` and the arrows unchanged.
    fn handle_captured_key(&mut self, cap: &InputCapture, key: Key) {
        // The hard release, first and unconditional: this is the only thing
        // standing between a wedged extension and a user who cannot quit, so
        // it must not depend on the extension answering the "prefix" that
        // follows — or on it being reachable at all.
        if key == cap.release {
            self.dispatch(Intent::SetInputCapture(None));
            self.dispatch(Intent::Extension(ExtensionIntent {
                extension: cap.owner.clone(),
                intent: "prefix".into(),
                data: ExtensionValue::Nil,
            }));
            return;
        }
        // Intent escapes: resolve exactly as an uncaptured key would, and if
        // the user pressed something that *means* "move the cursor", release
        // and let it mean that. Releasing and dispatching here — rather than
        // handing the extension the job of replaying the key — is what keeps
        // the two in the right order without any dispatch-ordering subtlety.
        if !cap.escape.is_empty() {
            let panel = self.state.focused_panel.clone();
            if let Some(intent) = self.keymap.resolve(&self.conditions, &self.state, &panel, key)
                && cap.escape.contains(&intent)
            {
                self.dispatch(Intent::SetInputCapture(None));
                self.dispatch(intent);
                return;
            }
        }
        self.dispatch(Intent::Extension(ExtensionIntent {
            extension: cap.owner.clone(),
            intent: "key".into(),
            data: codec::encode_key(key),
        }));
    }

    /// Handle an async completion: drop stale (mode-bound) results, then reduce.
    pub fn handle_async(&mut self, result: AsyncResult) {
        // Content reads are handed to the owning extension (which decodes +
        // stashes); they do not flow through the pure reducer.
        if result.purpose == Purpose::Content {
            if result.status == AsyncStatus::Ok {
                if let Payload::Read { owner, path, result: read } = result.payload {
                    // A form owner's explicit read (e.g. the CmdOp listing dir) is
                    // not cursor-follow: it bypasses the cursor-staleness gate and
                    // self-gates in accept_content, and does not reset the view.
                    let is_form = self.state.function.form_owner.as_deref() == Some(owner.as_str());
                    // Drop a cursor-follow read whose path is no longer under the
                    // cursor: the user navigated away while the read was in flight.
                    // Without this gate the late read would re-populate the preview
                    // the cursor-changed clear just dropped.
                    if !is_form && self.cursor_signature().0.as_deref() != Some(path.as_path()) {
                        return;
                    }
                    if let Some(ext) = self.extensions.find(&owner) {
                        ext.accept_content(&path, &read);
                    }
                    if !is_form {
                        // New content: reset the view (scroll / search) like a new file.
                        self.dispatch(Intent::ResetContentView);
                    }
                }
            }
            return;
        }
        if result.purpose == Purpose::Search {
            let bound = result.mode_generation == self.state.mode_generation()
                && matches!(self.state.mode(), Mode::Select(_));
            if !bound {
                return;
            }
        }
        let effects = core::apply_result(&mut self.state, result);
        self.process_effects(effects, 0);
        // A reload may move the cursor, and fresh search results change the
        // selection; re-broadcast the cursor-changed event either way.
        self.broadcast_cursor_changed();
    }

    /// The cursor identity for the broadcast gate: what's under the cursor (the
    /// File-mode entry, or the file-search candidate) and whether the function
    /// panel is open. Generic — it carries no extension-specific notion.
    fn cursor_signature(&self) -> (Option<std::path::PathBuf>, bool, usize, String) {
        let path = self.state.cursor_path();
        // Scroll is part of the signature so paging down re-broadcasts and the
        // content provider can fetch the next chunk as the viewport advances. The
        // mode id is part of it too, so pushing/popping an overlay extension mode
        // re-broadcasts — letting the ambient provider reclaim the panel on pop.
        (
            path,
            self.state.function.visible,
            self.state.function.scroll.offset(),
            self.state.mode_id(),
        )
    }

    /// Broadcast the generic **cursor-changed** event: when the cursor identity or
    /// panel visibility changes, call every registered extension's
    /// `on_cursor_changed` and re-dispatch the intents they return. The kernel
    /// knows nothing about any content extension here — the content provider is just one
    /// subscriber that returns `LoadContent` ([EXTENSION.md]).
    fn broadcast_cursor_changed(&mut self) {
        let sig = self.cursor_signature();
        if self.last_cursor == sig {
            return;
        }
        self.last_cursor = sig;
        let had_form = self.state.function.form_owner.is_some();
        self.notify_cursor_subscribers();
        // A subscriber may have handed the function panel back — a hosted
        // terminal stepping aside when the user moves the file cursor. Everyone
        // else already answered while it still owned the panel, and a content
        // provider declines to follow the cursor into a panel it does not own,
        // so they get one more pass. Exactly one: the panel cannot be handed
        // back twice, so this cannot recurse.
        if had_form && self.state.function.form_owner.is_none() {
            self.notify_cursor_subscribers();
        }
    }

    fn notify_cursor_subscribers(&mut self) {
        let intents: Vec<Intent> = {
            let state = &self.state;
            self.extensions.iter().flat_map(|e| e.on_cursor_changed(state)).collect()
        };
        for i in intents {
            self.dispatch_depth(i, false, 0);
        }
    }

    /// Give every extension a chance to turn out-of-band state into intents,
    /// once per event-loop pass. Unlike `broadcast_cursor_changed` this is not
    /// deduplicated — that is the whole point, since what it exists to catch
    /// (a child exiting on its own thread) leaves no trace in `AppState`.
    pub fn tick(&mut self) {
        let intents: Vec<Intent> = {
            let state = &self.state;
            self.extensions.iter().flat_map(|e| e.on_tick(state)).collect()
        };
        for i in intents {
            self.dispatch_depth(i, false, 0);
        }
    }

    /// Whether a Suspended execution is pending (the loop runs it).
    pub fn take_suspend(&mut self) -> Option<Vec<String>> {
        self.pending_suspend.take()
    }

    pub fn should_quit(&self) -> bool {
        self.state.quit
    }

    pub fn cwd(&self) -> std::path::PathBuf {
        self.state.cwd.clone()
    }

    /// After a suspend returns, drop back to the file list (the edit is over,
    /// regardless of outcome) and refresh. Refresh re-reads both the directory
    /// listing and the visible function-panel content, so an edit made in the
    /// suspended child (the editor) shows on return without moving the cursor.
    pub fn after_suspend(&mut self) {
        self.state.reset_to_file();
        self.dispatch(Intent::Refresh);
    }

    fn dispatch(&mut self, intent: Intent) {
        self.dispatch_depth(intent, false, 0);
    }

    fn dispatch_depth(&mut self, intent: Intent, confirmed: bool, depth: u32) {
        if depth > REDISPATCH_CAP {
            return;
        }

        // Policy mode is modal: only Confirm (allow) and Cancel (deny) act.
        let policy_pending = match self.state.mode() {
            Mode::Policy(p) => Some((**p).clone()),
            _ => None,
        };
        if let Some(pending) = policy_pending {
            match intent {
                Intent::Confirm => {
                    self.state.pop_mode();
                    self.dispatch_depth(pending, true, depth + 1);
                }
                Intent::Cancel => {
                    self.state.pop_mode();
                }
                _ => {}
            }
            return;
        }

        // Extension dispatch and the reserved resolver key.
        if let Intent::Extension(ext) = &intent {
            if ext.data.get(KEY_RESOLVER).is_some() {
                if let Some(req) = resolver_request(&ext.data) {
                    if self.needs_confirmation(&req) && !confirmed {
                        let i = intent.clone();
                        self.state.push_mode(Mode::Policy(Box::new(i)));
                        return;
                    }
                    self.spawn_plan(Plan::ResolveAndRun { request: req });
                } else {
                    crate::services::messages::log("malformed resolver intent", true);
                }
                return;
            }
            let ext = ext.clone();
            for i in self.extensions.dispatch(&ext, &self.state) {
                self.dispatch_depth(i, confirmed, depth + 1);
            }
            return;
        }

        // Confirmation gate: a destructive resolver op (e.g. delete), or one
        // that would silently overwrite an existing path (cp/mv's `-i`
        // condition) → Policy.
        if let Intent::RunResolver(req) = &intent {
            if self.needs_confirmation(req) && !confirmed {
                self.state.push_mode(Mode::Policy(Box::new(intent)));
                return;
            }
        }

        // KillProcess stops the streaming Execute child (the reducer then marks
        // the Exec frame finished).
        if matches!(intent, Intent::KillProcess) {
            self.tasks.kill_execute();
        }

        let effects = {
            let ctx = CmdCtx {
                commands: &self.commands,
                resolver: self.resolver.as_ref(),
                options: &self.option_cache,
            };
            core::apply_intent(&mut self.state, intent, &ctx)
        };
        self.process_effects(effects, depth);
    }

    /// Whether `req` needs a Policy confirmation before running: a
    /// statically destructive op (delete), or one that would silently
    /// overwrite an existing path — the dynamic `cp`/`mv -i` condition,
    /// which depends on the actual filesystem at dispatch time and so can't
    /// be a fixed property of the resolver entry the way `destructive` is.
    fn needs_confirmation(&self, req: &ResolverRequest) -> bool {
        self.resolver.is_destructive(&req.op)
            || crate::services::resolver::would_overwrite(req, &self.state.cwd)
    }

    fn process_effects(&mut self, effects: core::Effects, depth: u32) {
        for n in effects.notices {
            crate::services::messages::log(n.text, n.error);
        }
        for p in effects.plans {
            self.spawn_plan(p);
        }
        for i in effects.intents {
            self.dispatch_depth(i, false, depth + 1);
        }
    }

    /// The single seam between the message log and the on-screen notice: the
    /// newest line the user hasn't been shown yet — whether it came from the
    /// reducer's `Effects.notices` (drained into the log above) or straight
    /// from a boot/loader diagnostic — becomes the notice. Called every
    /// event-loop pass *before* the draw, so a notice logged while handling
    /// an event shows in that event's own frame, and a config mistake is
    /// visible at launch. Only the newest unseen line: the notice UI is a
    /// single 4-second slot; the full history is `@/messages`.
    pub fn surface_new_messages(&mut self) {
        if let Some((text, error, seq)) = crate::services::messages::global().latest_since(self.msg_seen) {
            self.msg_seen = seq;
            self.ui.notify(if error { core::Notice::error(text) } else { core::Notice::info(text) });
        }
    }

    fn spawn_plan(&mut self, plan: Plan) {
        if let Plan::Suspend { argv } = plan {
            self.pending_suspend = Some(argv);
            return;
        }
        let generation = self.state.mode_generation();
        let cwd = self.state.cwd.clone();
        self.tasks.spawn(plan, generation, cwd);
    }
}

/// A per-command memo of options parsed from `--help`/`man`, so the extraction
/// subprocess runs at most once per command.
type OptionCache = std::cell::RefCell<std::collections::HashMap<String, Vec<(String, String)>>>;

/// The reducer's command/resolver lookup: palette commands from the registry,
/// command-Select options from the resolver chain (the declared options, or those
/// parsed from the resolved command's `--help`/`man`). Combines the services
/// behind the single `CommandLookup` seam the pure reducer uses.
struct CmdCtx<'a> {
    commands: &'a CommandRegistry,
    resolver: &'a ResolverChain,
    options: &'a OptionCache,
}

impl core::CommandLookup for CmdCtx<'_> {
    fn intent_of(&self, name: &str) -> Option<Intent> {
        self.commands.intent_of(name)
    }
    fn command_candidates(&self) -> Vec<core::Candidate> {
        self.commands.candidates()
    }
    fn resolver_options(&self, op: &str) -> Vec<(String, String)> {
        let declared: Vec<(String, String)> =
            self.resolver.options(op).into_iter().map(|o| (o.token, o.label)).collect();
        // Parse the real command's options once (cached); fall back to declared.
        let Some(cmd) = self.resolver.command_of(op) else { return declared };
        let cached = self.options.borrow().get(&cmd).cloned();
        let extracted = match cached {
            Some(c) => c,
            None => {
                let parsed = crate::exec::extract_options(&cmd);
                self.options.borrow_mut().insert(cmd, parsed.clone());
                parsed
            }
        };
        if extracted.is_empty() { declared } else { extracted }
    }
    fn resolver_command(&self, op: &str) -> Vec<core::CmdToken> {
        use crate::services::resolver::{ArgEl, Slot};
        self.resolver
            .command_template(op)
            .into_iter()
            .map(|el| match el {
                ArgEl::Lit(s) => core::CmdToken::Lit(s),
                ArgEl::Ph(Slot::Opts) => core::CmdToken::Opts,
                ArgEl::Ph(Slot::Src) => core::CmdToken::Src,
                ArgEl::Ph(Slot::Paths) => core::CmdToken::Paths,
                ArgEl::Ph(Slot::Dst) => core::CmdToken::Dst,
                ArgEl::Ph(Slot::Path) => core::CmdToken::Path,
            })
            .collect()
    }
}

/// Build a ResolverRequest from an extension intent's reserved resolver data.
fn resolver_request(data: &ExtensionValue) -> Option<ResolverRequest> {
    let r = data.get(KEY_RESOLVER)?;
    let op = r.get("op")?.as_str()?.to_string();
    let src = r.get("src").and_then(|v| v.as_path()).cloned();
    let dst = r.get("dst").and_then(|v| v.as_str()).map(str::to_string);
    let path = r.get("path").and_then(|v| match v {
        ExtensionValue::Path(p) => Some(p.to_string_lossy().into_owned()),
        ExtensionValue::String(s) => Some(s.clone()),
        _ => None,
    });
    let paths = r
        .get("paths")
        .and_then(|v| v.as_list())
        .map(|l| l.iter().filter_map(|x| x.as_path().cloned()).collect())
        .unwrap_or_default();
    let opts = r
        .get("opts")
        .and_then(|v| v.as_list())
        .map(|l| l.iter().filter_map(|x| x.as_str().map(String::from)).collect())
        .unwrap_or_default();
    let label = r.get("label").and_then(|v| v.as_str()).unwrap_or(&op).to_string();
    Some(ResolverRequest { op, src, dst, path, paths, opts, label })
}

/// The embedded core option declarations; evaluated by the session (or parsed
/// directly when the session is not yet ready) to seed the `OptionStore`.
const CORE_OPTIONS_SCHEME: &str = include_str!("options.scm");

/// The embedded default resolver schema, in Scheme. Evaluated by the session so
/// Scheme is genuinely the source of truth for this configuration.
const RESOLVER_SCHEME: &str = include_str!("resolver.scm");

/// Eval a config Scheme const through the session, parse it into the registry
/// type, and fall back to the native embedded defaults on any eval or parse
/// failure (disable, notify, continue). The single shape shared by every
/// `scheme_*` config source below.
fn scheme_config<T>(
    session: &crate::script::SchemeSession,
    src: &str,
    label: &str,
    parse: impl FnOnce(&crate::script::sexpr::Datum) -> Result<Vec<T>, String>,
    fallback: impl FnOnce() -> Vec<T>,
) -> Vec<T> {
    session
        .eval(src)
        .and_then(|printed| crate::script::sexpr::parse(&printed))
        .and_then(|datum| parse(&datum))
        .unwrap_or_else(|e| {
            crate::services::messages::log(format!("scheme {label} config failed ({e}); using embedded defaults"), true);
            fallback()
        })
}

/// Source resolver entries from Scheme via the session; fall back to the native
/// embedded defaults on any eval or parse failure.
fn scheme_resolvers(session: &crate::script::SchemeSession) -> Vec<ResolverEntry> {
    scheme_config(
        session,
        RESOLVER_SCHEME,
        "resolver",
        |d| crate::script::config::parse_resolver_config(d),
        crate::services::resolver::defaults,
    )
}


/// The embedded default command palette, in Scheme: (name description intent).
const COMMAND_SCHEME: &str = include_str!("command.scm");

/// Source palette commands from Scheme via the session; fall back to defaults.
fn scheme_commands(session: &crate::script::SchemeSession) -> Vec<CommandDef> {
    scheme_config(
        session,
        COMMAND_SCHEME,
        "command",
        |d| crate::script::config::parse_command_config(d),
        crate::services::command::defaults,
    )
}

/// The embedded default keymap, in Scheme. Each group is
/// (mode panel-or-#f (binding...)); each binding is (key intent) or
/// (key intent when). This is the core layer only; extensions add their own.
const KEYMAP_SCHEME: &str = include_str!("keymap.scm");

/// Source the core keymap from Scheme via the session; fall back to defaults.
fn scheme_keymaps(session: &crate::script::SchemeSession) -> Vec<Binding> {
    scheme_config(
        session,
        KEYMAP_SCHEME,
        "keymap",
        |d| crate::script::config::parse_keymap_config(d, Layer::Core),
        crate::script::keymap::defaults,
    )
}

/// Shared dual-path Scheme evaluator: when the session is ready, evaluate `src`
/// through it and re-parse the printed result; otherwise parse the quoted literal
/// directly and unwrap the inner datum. Both paths return a `Datum` ready for a
/// config parser. `kind_desc` names the source for error messages.
fn eval_quoted_scheme(
    session: &crate::script::SchemeSession,
    ready: bool,
    src: &str,
    kind_desc: &str,
) -> Result<crate::script::sexpr::Datum, String> {
    if ready {
        session.eval(src).and_then(|p| crate::script::sexpr::parse(&p))
    } else {
        crate::script::sexpr::parse(src).and_then(|d| {
            d.as_list()
                .and_then(|l| l.get(1).cloned())
                .ok_or_else(|| format!("{kind_desc} is not a (quote …) form"))
        })
    }
}

/// Parse the core option declarations (`options.scm`) into `OptionDef`s.
fn scheme_core_option_defs(
    session: &crate::script::SchemeSession,
    ready: bool,
) -> Vec<OptionDef> {
    match eval_quoted_scheme(session, ready, CORE_OPTIONS_SCHEME, "core options source")
        .and_then(|d| crate::script::config::parse_option_config(&d))
    {
        Ok(defs) => defs,
        Err(e) => {
            crate::services::messages::log(format!("core option defs failed ({e}); no options registered"), true);
            Vec::new()
        }
    }
}

/// Parse an extension's `option_scheme()` into `OptionDef`s.
fn extension_option_defs(
    session: &crate::script::SchemeSession,
    ready: bool,
    ext: &dyn crate::extension::Extension,
) -> Vec<OptionDef> {
    let Some(src) = ext.option_scheme() else {
        return Vec::new();
    };
    match eval_quoted_scheme(session, ready, &src, "extension option source")
        .and_then(|d| crate::script::config::parse_option_config(&d))
    {
        Ok(mut defs) => {
            // Tag each def with its owning extension so settings groups them under
            // @/settings/Extensions/<id> rather than as a flat category.
            for d in &mut defs {
                d.owner = Some(ext.id().to_string());
            }
            defs
        }
        Err(e) => {
            crate::services::messages::log(format!("extension '{}' option defs failed ({e}); ignoring", ext.id()), true);
            Vec::new()
        }
    }
}

/// Evaluate an extension's declarative Scheme source into Extension-layer keymap
/// bindings. The source is `(quote ((mode panel (binding…)) …))`.
fn extension_scheme_keymaps(
    session: &crate::script::SchemeSession,
    ready: bool,
    ext: &dyn crate::extension::Extension,
) -> Vec<Binding> {
    let Some(src) = ext.scheme_source() else {
        return Vec::new();
    };
    match eval_quoted_scheme(session, ready, &src, "extension scheme source")
        .and_then(|d| crate::script::config::parse_keymap_config(&d, Layer::Extension))
    {
        Ok(binds) => binds,
        Err(e) => {
            crate::services::messages::log(format!("extension '{}' scheme keymap failed ({e}); ignoring", ext.id()), true);
            Vec::new()
        }
    }
}

/// Load optional extensions from the extensions directory. Skipped in tests
/// (the loader's glue parsing is covered directly).
fn load_optional_extensions() -> Vec<Box<dyn crate::extension::Extension>> {
    if cfg!(test) {
        return Vec::new();
    }
    let dir = std::env::var_os("WASDF_EXTENSIONS_DIR")
        .map(std::path::PathBuf::from)
        .or_else(|| config_dir().map(|d| d.join("extensions")));
    match dir {
        Some(d) => crate::extension::loader::load_optional(&d),
        None => Vec::new(),
    }
}

/// The user config directory ($WASDF_CONFIG_DIR, else XDG config, else
/// ~/.config), created on demand. None only if no home is discoverable.
fn config_dir() -> Option<std::path::PathBuf> {
    let base = std::env::var_os("WASDF_CONFIG_DIR")
        .map(std::path::PathBuf::from)
        .or_else(|| std::env::var_os("XDG_CONFIG_HOME").map(std::path::PathBuf::from))
        .or_else(|| std::env::var_os("HOME").map(|h| std::path::PathBuf::from(h).join(".config")))?;
    let dir = if std::env::var_os("WASDF_CONFIG_DIR").is_some() {
        base
    } else {
        base.join("wasdf")
    };
    std::fs::create_dir_all(&dir).ok()?;
    Some(dir)
}

/// Apply a single `(set-option key value)` pair from the config loader. Warns
/// when the value is rejected by the def's kind validator (unknown keys are
/// silently stashed in `unowned` for late-arriving optional extensions).
fn apply_option(store: &OptionStore, key: &str, val: &str) {
    if !store.set(key, val) && store.def(key).is_some() {
        crate::services::messages::log(format!("user config: invalid value '{val}' for option '{key}'"), true);
    }
}

/// Rebuild the typed `MatcherConfig` from current store values. Mirrors the
/// same helper in `settings.rs`; called at boot after user config is applied.
fn project_matcher(os: &OptionStore, cfg: &Mutex<MatcherConfig>) {
    let mut mc = cfg.lock().unwrap();
    mc.tail_bonus = os.get_i64("matcher.tail-bonus");
    mc.depth_penalty = os.get_i64("matcher.depth-penalty");
    mc.length_penalty = os.get_i64("matcher.length-penalty");
    mc.exec_bonus = os.get_i64("matcher.exec-bonus");
    mc.preferred_ext = os.get_list("matcher.preferred-ext");
    mc.noise_ext = os.get_list("matcher.noise-ext");
    mc.noise_dirs = os.get_list("matcher.noise-dirs");
    mc.max_results = os.get_u32("matcher.max-results") as usize;
}

/// Load the user configuration: write the commented template (`config.scm`) if
/// absent, then parse the uncommented `(bind …)` and `(set-option …)` lines.
/// The User layer wins via priority; deleting the file reproduces the defaults.
fn scheme_user_config(
    session: &crate::script::SchemeSession,
    store: &OptionStore,
) -> (Vec<Binding>, Vec<(String, String)>) {
    // Tests never touch the real user config; the user-config decode path is
    // covered directly by parse_user_config / config_template tests.
    if cfg!(test) {
        return (Vec::new(), Vec::new());
    }
    let Some(dir) = config_dir() else { return (Vec::new(), Vec::new()) };
    // Accept config.scm; fall back to the old keybindings.scm name for
    // backward compatibility with existing user configs.
    let path = {
        let new_path = dir.join("config.scm");
        let old_path = dir.join("keybindings.scm");
        if !new_path.exists() && old_path.exists() {
            old_path
        } else {
            if !new_path.exists() {
                let _ = std::fs::write(&new_path, config_template(store));
            }
            new_path
        }
    };
    let Ok(contents) = std::fs::read_to_string(&path) else { return (Vec::new(), Vec::new()) };
    // Read the uncommented forms as data through the session, so the Scheme
    // reader handles comment stripping and syntax validation.
    let expr = format!("(quote ({contents}))");
    match session
        .eval(&expr)
        .and_then(|printed| crate::script::sexpr::parse(&printed))
        .and_then(|datum| parse_user_config(&datum))
    {
        Ok(result) => result,
        Err(e) => {
            crate::services::messages::log(format!("user config failed ({e}); ignoring user overrides"), true);
            (Vec::new(), Vec::new())
        }
    }
}

fn parse_user_config(
    datum: &crate::script::sexpr::Datum,
) -> Result<(Vec<Binding>, Vec<(String, String)>), String> {
    use crate::script::sexpr::Datum;
    let forms = datum.as_list().ok_or("user config is not a list")?;
    let mut binds = Vec::new();
    let mut opts = Vec::new();
    for form in forms {
        let p = form.as_list().ok_or("config form is not a list")?;
        match p.first().and_then(|d| d.as_sym()) {
            Some("bind") => {
                let mode =
                    p.get(1).and_then(|d| d.as_sym()).ok_or("bind missing mode")?.to_string();
                let panel = match p.get(2) {
                    Some(Datum::Bool(false)) => None,
                    Some(d) => d.as_sym().map(str::to_string),
                    None => None,
                };
                let key_name = p.get(3).and_then(|d| d.text()).ok_or("bind missing key")?;
                let key = crate::script::codec::parse_key(key_name)
                    .ok_or_else(|| format!("unknown key: {key_name}"))?;
                let intent = p
                    .get(4)
                    .and_then(crate::script::codec::intent_from_datum)
                    .ok_or("bind has an unknown intent")?;
                // Same shape as a keymap.scm binding: after the intent come the
                // `:when` and/or the help label, told apart by type rather than
                // by position (doc/HELP.md).
                let rest = p.get(5..).unwrap_or_default();
                let help = rest.iter().find_map(|d| d.as_str()).map(str::to_string);
                let when = rest
                    .iter()
                    .find(|d| d.as_str().is_none())
                    .map(crate::script::codec::cond_from_datum)
                    .unwrap_or(Cond::Always);
                binds.push(Binding { mode, panel, key, intent, when, layer: Layer::User, help });
            }
            Some("set-option") => {
                let key =
                    p.get(1).and_then(|d| d.text()).ok_or("set-option missing key")?.to_string();
                let val =
                    p.get(2).and_then(|d| d.text()).ok_or("set-option missing value")?.to_string();
                opts.push((key, val));
            }
            // Theme forms live in the same managed block but are consumed by the
            // theme extension's own boot loader (see extension/theme.rs), not here.
            Some("set-theme") | Some("define-theme") => {}
            // Other unrecognised forms are skipped silently: this runs after the
            // TUI owns the alternate screen, so an eprintln would corrupt it.
            Some(_) => {}
            None => return Err("empty config form".into()),
        }
    }
    Ok((binds, opts))
}

/// Generate the unified configuration template (`config.scm`): option stubs
/// derived from the store's declared options, followed by every default
/// keybinding commented out so the user can uncomment and edit individual lines.
fn config_template(store: &OptionStore) -> String {
    let mut s = String::from(
        ";; wasdf configuration — uncomment and edit a line to override a default.\n\
         ;; Deleting this file restores the built-in defaults exactly.\n\n\
         ;; Options\n",
    );
    for (cat, defs) in store.categories() {
        s.push_str(&format!(";; {cat}\n"));
        for def in defs {
            let hint = def.kind.hint();
            if hint.is_empty() {
                s.push_str(&format!(
                    ";; (set-option \"{}\" \"{}\")\n",
                    def.key, def.default
                ));
            } else {
                s.push_str(&format!(
                    ";; (set-option \"{}\" \"{}\")  ; {}\n",
                    def.key, def.default, hint
                ));
            }
        }
    }
    s.push_str("\n;; Keybindings\n;; Form: (bind <mode> <panel|#f> \"<key>\" <intent> [<when>])\n\n");
    if let Ok(quoted) = crate::script::sexpr::parse(KEYMAP_SCHEME) {
        // KEYMAP_SCHEME parses as (quote (<group> …)); take the groups.
        if let Some(groups) = quoted.as_list().and_then(|l| l.get(1)).and_then(|d| d.as_list()) {
            for group in groups {
                let Some(g) = group.as_list() else { continue };
                let (Some(mode), Some(panel), Some(binds)) =
                    (g.first(), g.get(1), g.get(2).and_then(|d| d.as_list()))
                else {
                    continue;
                };
                for b in binds {
                    let Some(bp) = b.as_list() else { continue };
                    let mut parts = vec![
                        "bind".to_string(),
                        crate::script::sexpr::render(mode),
                        crate::script::sexpr::render(panel),
                    ];
                    for el in bp {
                        parts.push(crate::script::sexpr::render(el));
                    }
                    s.push_str("; (");
                    s.push_str(&parts.join(" "));
                    s.push_str(")\n");
                }
            }
        }
    }
    s
}

#[cfg(test)]
impl App {
    /// Drive an intent through the full pipeline, then broadcast cursor-changed
    /// (as handle_key does), so tests see the auto content-follow (test seam).
    pub fn dispatch_for_test(&mut self, intent: Intent) {
        self.dispatch(intent);
        self.broadcast_cursor_changed();
    }

    /// Block until one async result arrives and reduce it (test seam).
    pub fn pump_one(&mut self) {
        if let Ok(AppEvent::Async(r)) = self.rx.recv() {
            self.handle_async(r);
        }
    }

    /// The active content provider's logical row count, if it produced a view.
    pub fn function_content_rows(&self) -> Option<usize> {
        self.provider_view().map(|v| match v {
            crate::core::PanelView::Document(blocks) => blocks.len(),
            crate::core::PanelView::Image { .. } => 1,
        })
    }

    /// The function-panel title for the active provider's view (the cursor file
    /// name + any search position), if the provider produced a view.
    pub fn function_title(&self) -> Option<String> {
        self.provider_view().map(|_| {
            crate::ui::content::title(self.cursor_signature().0.as_deref(), &self.state.function.search)
        })
    }

    fn provider_view(&self) -> Option<crate::core::PanelView> {
        let theme = crate::core::Theme::default();
        let sources = self.state.targets();
        let ctx = crate::extension::FunctionRenderCtx {
            width: 80,
            height: 24,
            focused: true,
            func: &self.state.function,
            sources: &sources,
            theme: &theme,
        };
        self.extensions.provider().and_then(|p| p.view(&ctx))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::{Mods, SubLayout};

    fn temp_dir_with_files() -> std::path::PathBuf {
        use std::sync::atomic::{AtomicU32, Ordering};
        static SEQ: AtomicU32 = AtomicU32::new(0);
        let n = SEQ.fetch_add(1, Ordering::Relaxed);
        let mut dir = std::env::temp_dir();
        dir.push(format!("wasdf-test-{}-{}", std::process::id(), n));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join("alpha.txt"), b"hello\nworld\n").unwrap();
        std::fs::write(dir.join("beta.txt"), b"second file").unwrap();
        std::fs::create_dir_all(dir.join("subdir")).unwrap();
        dir
    }

    /// An extension that records the captured keys it is handed and otherwise
    /// does nothing at all — in particular it never releases the capture. The
    /// lockout guarantee only means something if it holds against an extension
    /// that refuses to cooperate, so that is what these tests use.
    #[derive(Default)]
    struct InertCapturer {
        got: std::sync::Mutex<Vec<String>>,
    }

    impl Extension for InertCapturer {
        fn id(&self) -> &str {
            "capturer"
        }
        fn handle_intent(&self, i: &ExtensionIntent, _s: &AppState) -> Vec<Intent> {
            let label = match i.intent.as_str() {
                "key" => codec::decode_key(&i.data).map(codec::key_name).unwrap_or_default(),
                other => format!("<{other}>"),
            };
            self.got.lock().unwrap().push(label);
            Vec::new()
        }
    }

    /// Boot an app with `InertCapturer` registered and a capture already
    /// installed: released by `Ctrl-b`, escaping on `escape`.
    fn app_capturing(escape: Vec<Intent>) -> (App, std::sync::Arc<InertCapturer>) {
        // The registry takes a Box, so keep a parallel Arc purely to read the
        // recorded keys back out; both point at the same recording Mutex only
        // if we register the Arc itself.
        let ext = std::sync::Arc::new(InertCapturer::default());
        struct Shim(std::sync::Arc<InertCapturer>);
        impl Extension for Shim {
            fn id(&self) -> &str {
                self.0.id()
            }
            fn handle_intent(&self, i: &ExtensionIntent, s: &AppState) -> Vec<Intent> {
                self.0.handle_intent(i, s)
            }
        }
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir);
        app.pump_one();
        app.extensions.register(Box::new(Shim(ext.clone())));
        app.dispatch_for_test(Intent::SetInputCapture(Some(Box::new(InputCapture {
            owner: "capturer".into(),
            release: Key::new(KeyCode::Char('b'), Mods::CTRL),
            escape,
        }))));
        (app, ext)
    }

    #[test]
    fn a_captured_bound_key_reaches_the_extension_instead_of_acting() {
        let (mut app, ext) = app_capturing(Vec::new());
        // `q` quits in File mode. Under capture it must not.
        app.handle_key(Key::plain(KeyCode::Char('q')));
        assert!(!app.state.quit, "q must not quit while captured");
        assert_eq!(ext.got.lock().unwrap().as_slice(), ["q"]);
    }

    #[test]
    fn the_release_key_frees_the_user_even_when_the_extension_does_nothing() {
        let (mut app, ext) = app_capturing(Vec::new());
        app.handle_key(Key::new(KeyCode::Char('b'), Mods::CTRL));
        assert!(
            app.state.input_capture.is_none(),
            "the release must not depend on the extension answering"
        );
        assert_eq!(ext.got.lock().unwrap().as_slice(), ["<prefix>"]);
    }

    #[test]
    fn an_escape_intent_releases_the_capture_and_still_performs_the_move() {
        let escape = vec![Intent::CursorUp, Intent::CursorDown, Intent::CursorLeft,
                          Intent::CursorRight, Intent::CursorTop, Intent::CursorBottom];
        let (mut app, ext) = app_capturing(escape);
        assert_eq!(app.state.cursor, 0);
        // `s` is CursorDown in the default file-panel keymap.
        app.handle_key(Key::plain(KeyCode::Char('s')));
        assert!(app.state.input_capture.is_none(), "escape intent releases");
        assert_eq!(app.state.cursor, 1, "and the move it stands for happens");
        assert!(ext.got.lock().unwrap().is_empty(), "the key never reaches the extension");
    }

    #[test]
    fn cursor_bottom_escapes_too_not_just_the_four_wasd_moves() {
        let escape = vec![Intent::CursorUp, Intent::CursorDown, Intent::CursorLeft,
                          Intent::CursorRight, Intent::CursorTop, Intent::CursorBottom];
        let (mut app, _) = app_capturing(escape);
        // `S` (shift-s) is CursorBottom.
        app.handle_key(Key::plain(KeyCode::Char('S')));
        assert!(app.state.input_capture.is_none());
        assert_eq!(app.state.cursor, app.state.entries.len() - 1);
    }

    #[test]
    fn with_no_escape_intents_a_movement_key_goes_to_the_child() {
        let (mut app, ext) = app_capturing(Vec::new());
        app.handle_key(Key::plain(KeyCode::Char('s')));
        assert!(app.state.input_capture.is_some(), "PrefixOnly keeps the capture");
        assert_eq!(app.state.cursor, 0, "and the cursor stays put");
        assert_eq!(ext.got.lock().unwrap().as_slice(), ["s"]);
    }

    #[test]
    fn activate_is_not_an_escape() {
        let escape = vec![Intent::CursorUp, Intent::CursorDown, Intent::CursorLeft,
                          Intent::CursorRight, Intent::CursorTop, Intent::CursorBottom];
        let (mut app, ext) = app_capturing(escape);
        app.handle_key(Key::plain(KeyCode::Enter));
        assert!(app.state.input_capture.is_some());
        assert_eq!(ext.got.lock().unwrap().as_slice(), ["Enter"]);
    }

    #[test]
    fn a_key_release_never_fires_its_binding() {
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir);
        app.pump_one();
        let down = Key::plain(KeyCode::Char('s'));
        app.handle_key(down);
        app.handle_key(Key { kind: crate::core::KeyKind::Release, ..down });
        assert_eq!(app.state.cursor, 1, "the release must not move the cursor a second time");
    }

    #[test]
    fn boots_and_lists_directory() {
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir.clone());
        app.pump_one(); // initial ReadDir
        assert_eq!(app.state.entries.len(), 3, "subdir, alpha, beta");
        // Directory sorts first.
        assert!(app.state.entries[0].is_dir);
    }

    #[test]
    fn cursor_and_selection() {
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir);
        app.pump_one();
        assert_eq!(app.state.cursor, 0);
        app.dispatch_for_test(Intent::CursorDown);
        assert_eq!(app.state.cursor, 1);
        app.dispatch_for_test(Intent::ToggleSelect);
        assert_eq!(app.state.selection.len(), 1);
        app.dispatch_for_test(Intent::ClearSelection);
        assert!(app.state.selection.is_empty());
    }

    #[test]
    fn cursor_right_on_file_loads_content() {
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir);
        app.pump_one();
        // Move to a file (skip the directory at index 0).
        app.dispatch_for_test(Intent::CursorDown);
        app.dispatch_for_test(Intent::CursorRight);
        assert!(app.state.function.visible);
        assert_eq!(app.state.function.sublayout, SubLayout::Content);
        app.pump_one(); // content read → handed to the content provider's stash
        assert!(app.function_content_rows().is_some());
    }

    #[test]
    fn content_read_off_the_cursor_is_dropped() {
        // Reproduces the empty-directory race: a content read that was in flight
        // when the cursor left its target (navigating into an empty directory)
        // must be dropped on arrival, so it does not re-populate the preview that
        // the cursor-changed clear already dropped.
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir.clone());
        app.pump_one(); // initial ReadDir

        // Show the function panel on a file and load its content.
        app.dispatch_for_test(Intent::CursorDown); // off the directory, onto a file
        app.dispatch_for_test(Intent::CursorRight); // reveal + follow
        app.pump_one(); // the content read is accepted (cursor still on it)
        assert!(app.function_content_rows().is_some(), "preview loaded for the file");

        // Simulate entering an empty directory: no entries, so nothing is under the
        // cursor. The cursor-changed clear drops the stale preview.
        app.state.entries.clear();
        app.state.cursor = 0;
        app.broadcast_cursor_changed();
        assert!(app.function_content_rows().is_none(), "preview cleared on empty dir");

        // A late read for the file we navigated away from arrives — it must be
        // dropped, not re-stashed.
        let stale = AsyncResult {
            request_id: 0,
            purpose: Purpose::Content,
            mode_generation: app.state.mode_generation(),
            status: AsyncStatus::Ok,
            payload: Payload::Read {
                owner: "preview".into(),
                path: dir.join("alpha.txt"),
                result: crate::core::ReadResult::Bytes {
                    offset: 0,
                    bytes: b"STALE\n".to_vec(),
                    eof: true,
                },
            },
        };
        app.handle_async(stale);
        assert!(
            app.function_content_rows().is_none(),
            "a content read off the current cursor must not repopulate the preview",
        );
    }

    #[test]
    fn delete_pushes_policy_then_confirms() {
        let dir = temp_dir_with_files();
        let target = dir.join("beta.txt");
        let mut app = App::boot(dir);
        app.pump_one();
        // Select beta.txt and request delete.
        app.state.cursor = app
            .state
            .entries
            .iter()
            .position(|e| e.path == target)
            .unwrap();
        app.dispatch_for_test(Intent::DeleteSelected);
        assert!(matches!(app.state.mode(), Mode::Policy(_)), "delete gates on Policy");
        app.dispatch_for_test(Intent::Confirm); // allow
        assert!(matches!(app.state.mode(), Mode::File));
        app.pump_one(); // OpDone → triggers refresh
        app.pump_one(); // refresh entries
        assert!(!target.exists(), "beta.txt deleted");
    }

    #[test]
    fn cmdop_deep_search_submit_lands_through_the_real_kernel_pipeline() {
        // Reproduces SEARCH_RENEW.md scenario 4 end-to-end: start-copy, "/" for
        // deep search, type + Enter through the real handle_key path (not
        // dispatch_for_test, which bypasses the function.input raw-key gate and
        // the real async round trip) — the exact layer the reducer-only and
        // extension-only unit tests never exercise.
        use crate::core::ExtensionIntent;
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir.clone());
        app.pump_one(); // initial ReadDir
        app.dispatch_for_test(Intent::CursorDown); // off subdir, onto alpha.txt
        assert_eq!(app.state.current_entry().unwrap().name, "alpha.txt");

        app.dispatch_for_test(Intent::Extension(ExtensionIntent {
            extension: "cmdop".into(),
            intent: "start-copy".into(),
            data: ExtensionValue::Nil,
        }));
        assert_eq!(app.state.function.form_owner.as_deref(), Some("cmdop"));
        app.pump_one(); // the browse dir's own LoadContent listing lands

        app.dispatch_for_test(Intent::Extension(ExtensionIntent {
            extension: "cmdop".into(),
            intent: "filter-start".into(),
            data: ExtensionValue::Nil,
        }));
        assert!(app.state.function.input.is_some(), "search-deep input is open");
        assert_eq!(app.state.function.input.as_ref().unwrap().purpose, "search-deep");

        for c in "alpha".chars() {
            app.handle_key(Key::plain(KeyCode::Char(c)));
        }
        assert_eq!(
            app.state.function.input.as_ref().unwrap().query, "alpha",
            "each character reached the query buffer, none were hijacked as file-cursor keymap bindings",
        );
        app.handle_key(Key::plain(KeyCode::Enter));
        assert!(app.state.function.input.is_none(), "Enter closed the input box");
        assert_eq!(
            app.state.function.form_owner.as_deref(), Some("cmdop"),
            "the builder is still open — Enter must not have fallen through to a stray keymap binding",
        );

        app.pump_one(); // the owner-addressed Plan::Search completes as a content Read
        assert_eq!(app.state.function.form_owner.as_deref(), Some("cmdop"), "still open after the search lands");
    }

    #[test]
    fn copy_onto_an_existing_file_gates_on_policy_like_delete() {
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir.clone());
        app.pump_one();
        // beta.txt already exists — copying alpha.txt onto it must confirm
        // first, the same `-i` condition real `cp`/`mv` prompt on.
        let req = crate::core::ResolverRequest {
            op: "copy".into(),
            src: None,
            dst: Some("beta.txt".into()),
            path: None,
            paths: vec![dir.join("alpha.txt")],
            opts: vec![],
            label: "copy".into(),
        };
        app.dispatch_for_test(Intent::RunResolver(req));
        assert!(matches!(app.state.mode(), Mode::Policy(_)), "copy onto an existing file gates on Policy");
    }

    #[test]
    fn copy_to_a_new_name_runs_without_confirmation() {
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir.clone());
        app.pump_one();
        let req = crate::core::ResolverRequest {
            op: "copy".into(),
            src: None,
            dst: Some("brand-new.txt".into()),
            path: None,
            paths: vec![dir.join("alpha.txt")],
            opts: vec![],
            label: "copy".into(),
        };
        app.dispatch_for_test(Intent::RunResolver(req));
        assert!(matches!(app.state.mode(), Mode::File), "no existing target — runs immediately, no Policy gate");
    }

    #[test]
    fn file_search_loads_selected_candidate() {
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir);
        app.pump_one(); // initial ReadDir
        app.dispatch_for_test(Intent::PushMode(Box::new(Mode::Select(
            crate::core::SelectSpec::file_search(),
        ))));
        app.pump_one(); // Search result → populates the entry view + spawns the dir content read
        assert!(!app.state.select.as_ref().unwrap().view.as_ref().unwrap().is_empty());
        app.pump_one(); // content read for the highlighted candidate (dir listing)
        assert!(app.function_content_rows().is_some(), "file-search follows the dir content");
    }

    #[test]
    fn content_auto_update_follows_file_cursor() {
        use crate::core::{Key, KeyCode};
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir);
        app.pump_one();
        app.store.set("content-auto-update", "#t");
        app.state.function.visible = true;
        app.state.focused_panel = "file".into();
        // Move the file cursor; the on_cursor_move hook reads the file's content.
        app.handle_key(Key::plain(KeyCode::Char('s')));
        assert_eq!(app.state.cursor, 1);
        app.pump_one(); // the auto-update content read
        assert!(app.function_content_rows().is_some());
    }

    #[test]
    fn effects_notices_reach_the_log_and_surface_with_their_error_attribute() {
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir);
        app.surface_new_messages(); // drain anything boot itself logged
        // A unique text: the log is process-global and other tests may push
        // concurrently, so assert containment, not exact contents.
        let text = format!("notice-unified-{}", std::process::id());
        let fx = core::Effects { notices: vec![core::Notice::info(text.clone())], ..Default::default() };
        app.process_effects(fx, 0);
        assert!(
            crate::services::messages::global().lines().contains(&(text.clone(), false)),
            "a reducer notice is a retained @/messages line, error attribute intact"
        );
        app.surface_new_messages();
        let n = app.ui.live_notice().expect("the pump surfaces the logged notice");
        assert!(!n.error, "an info notice keeps its info styling through the log");
    }

    #[test]
    fn a_raw_log_line_surfaces_as_an_error_notice() {
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir);
        app.surface_new_messages(); // drain anything boot itself logged
        crate::services::messages::log("some boot diagnostic", true);
        app.surface_new_messages();
        let n = app.ui.live_notice().expect("an unseen log line surfaces as a notice");
        assert!(n.error, "the error attribute carries through to the notice styling");
    }

    #[test]
    fn resolver_table_sourced_from_scheme() {
        let session = crate::script::SchemeSession::spawn();
        session.wait_ready(Duration::from_secs(600));
        let entries = scheme_resolvers(&session);
        let copy = entries.iter().find(|e| e.key == "copy").expect("copy entry");
        assert!(!copy.destructive);
        let del = entries.iter().find(|e| e.key == "delete").expect("delete entry");
        assert!(del.destructive, "delete is destructive per the Scheme config");
        let open = entries.iter().find(|e| e.key == "open").expect("open entry");
        assert_eq!(open.candidates.len(), 2, "open has macos + linux candidates");
    }

    #[test]
    fn commands_sourced_from_scheme() {
        let session = crate::script::SchemeSession::spawn();
        session.wait_ready(Duration::from_secs(600));
        let cmds = scheme_commands(&session);
        assert!(cmds.iter().any(|c| c.name == "quit"));
        // copy/move/rename/mkdir/touch are contributed natively by the cmdop
        // extension's commands(), not command.scm — see its own doc comment.
        let home = cmds.iter().find(|c| c.name == "home").expect("home command");
        assert!(matches!(home.intent, Intent::NavigateTo(_)), "home navigates to the VFS root");
    }

    #[test]
    fn keymap_sourced_from_scheme() {
        use crate::core::{Key, KeyCode, Mods};
        let session = crate::script::SchemeSession::spawn();
        session.wait_ready(Duration::from_secs(600));
        let binds = scheme_keymaps(&session);
        assert!(binds.len() > 30, "core keymap has many bindings, got {}", binds.len());

        let mut km = KeymapRegistry::new();
        km.extend(binds);
        let conds = Conditions::default();
        let state = AppState::new(std::env::temp_dir());
        // file mode, file panel: 'w' resolves to CursorUp via the Scheme keymap.
        let up = km.resolve(&conds, &state, "file", Key::plain(KeyCode::Char('w')));
        assert_eq!(up, Some(Intent::CursorUp));
        // Ctrl-a resolves to SelectAll (modifier parsing works).
        let all = km.resolve(&conds, &state, "file", Key::new(KeyCode::Char('a'), Mods::CTRL));
        assert_eq!(all, Some(Intent::SelectAll));
        // Delete fires on both Backspace and Delete.
        for code in [KeyCode::Backspace, KeyCode::Delete] {
            let got = km.resolve(&conds, &state, "file", Key::plain(code));
            assert_eq!(got, Some(Intent::DeleteSelected), "{code:?} → delete");
        }
    }

    #[test]
    fn user_keybindings_parsed_at_user_layer() {
        use crate::core::{Key, KeyCode};
        let session = crate::script::SchemeSession::spawn();
        session.wait_ready(Duration::from_secs(600));
        // Commented lines are ignored; uncommented (bind …) forms become User
        // overrides. Includes a `:when` and a #f (no-panel) scope.
        let printed = session
            .eval(
                "(quote (\
                   ; (bind file file \"w\" cursor-up)\n\
                   (bind file file \"z\" cursor-bottom)\
                   (bind file #f \"Q\" quit)))",
            )
            .unwrap();
        let datum = crate::script::sexpr::parse(&printed).unwrap();
        let (binds, opts) = parse_user_config(&datum).unwrap();
        assert_eq!(binds.len(), 2, "the commented line is skipped");
        assert!(opts.is_empty());
        assert!(binds.iter().all(|b| b.layer == Layer::User));
        let z = &binds[0];
        assert_eq!(z.key, Key::plain(KeyCode::Char('z')));
        assert_eq!(z.intent, Intent::CursorBottom);
        assert_eq!(binds[1].panel, None);
    }

    #[test]
    fn config_template_is_commented() {
        let defs = {
            let outer = crate::script::sexpr::parse(CORE_OPTIONS_SCHEME).unwrap();
            let inner = outer.as_list().unwrap()[1].clone();
            crate::script::config::parse_option_config(&inner).unwrap()
        };
        let store = OptionStore::new(defs);
        let t = config_template(&store);
        assert!(t.contains("; (bind file file \"w\" cursor-up \"cursor\")"));
        assert!(t.contains("; (bind select #f \"Enter\" confirm \"confirm/next\")"));
        // Every binding line is commented out.
        assert!(t.lines().filter(|l| l.contains("(bind ")).all(|l| l.trim_start().starts_with(';')));
        // Option stubs are present.
        assert!(t.contains("set-option \"border-style\""));
    }

    #[test]
    fn set_option_parsed_from_config() {
        use crate::script::SchemeSession;
        let session = SchemeSession::spawn();
        session.wait_ready(Duration::from_secs(600));
        let printed = session
            .eval("(quote ((set-option \"border-style\" \"rounded\") (set-option \"content-auto-update\" \"#t\")))")
            .unwrap();
        let datum = crate::script::sexpr::parse(&printed).unwrap();
        let (binds, opts) = parse_user_config(&datum).unwrap();
        assert!(binds.is_empty());
        assert_eq!(opts.len(), 2);
        assert_eq!(opts[0], ("border-style".into(), "rounded".into()));
        assert_eq!(opts[1], ("content-auto-update".into(), "#t".into()));
        let defs = {
            let outer = crate::script::sexpr::parse(CORE_OPTIONS_SCHEME).unwrap();
            let inner = outer.as_list().unwrap()[1].clone();
            crate::script::config::parse_option_config(&inner).unwrap()
        };
        let store = OptionStore::new(defs);
        for (k, v) in &opts {
            apply_option(&store, k, v);
        }
        assert_eq!(store.get_str("border-style"), "rounded");
        assert!(store.get_bool("content-auto-update"));
    }

    #[test]
    fn execute_streams_output() {
        use crate::core::SubLayout;
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir);
        app.pump_one(); // initial ReadDir
        // Execute a command that emits three lines; the reducer opens the Exec
        // frame and the executor streams output line-by-line.
        app.dispatch_for_test(Intent::Execute {
            argv: vec!["sh".into(), "-c".into(), "echo a; echo b; echo c".into()],
        });
        assert_eq!(app.state.function.sublayout, SubLayout::Exec);
        assert!(!app.state.function.exec.finished);
        let mut guard = 0;
        while !app.state.function.exec.finished && guard < 100 {
            app.pump_one();
            guard += 1;
        }
        assert!(app.state.function.exec.finished, "exec did not finish");
        let lines = &app.state.function.exec.lines;
        assert!(
            lines.contains(&"a".to_string()) && lines.contains(&"c".to_string()),
            "streamed lines: {lines:?}"
        );
        assert_eq!(app.state.function.exec.exit, Some(0));
    }

    #[test]
    fn eval_scheme_runs_through_the_pipeline() {
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir);
        app.scheme.wait_ready(Duration::from_secs(600));
        app.pump_one(); // initial ReadDir
        // Issue an EvalScheme plan; the resident Scheme session computes it and the
        // result returns as an AsyncResult the reducer turns into a notice.
        let generation = app.state.mode_generation();
        let cwd = app.cwd();
        app.tasks
            .spawn(Plan::EvalScheme { expr: "(+ 40 2)".into() }, generation, cwd);
        app.pump_one(); // Scheme result
        app.surface_new_messages(); // notices reach the screen via the per-frame pump
        let shown = app.ui.live_notice().map(|n| n.text.clone()).unwrap_or_default();
        assert!(shown.contains("42"), "scheme result surfaced: {shown:?}");
    }

    #[test]
    fn cursor_left_lands_on_origin_directory() {
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir.clone());
        app.pump_one();
        // Enter subdir (index 0, the only directory).
        assert!(app.state.entries[0].is_dir);
        app.dispatch_for_test(Intent::CursorRight);
        app.pump_one(); // listing of subdir
        assert_eq!(app.state.cwd, dir.join("subdir"));
        // Go back to the parent; cursor should land on "subdir".
        app.dispatch_for_test(Intent::CursorLeft);
        app.pump_one(); // listing of parent
        assert_eq!(app.state.cwd, dir);
        assert_eq!(app.state.current_entry().unwrap().path, dir.join("subdir"));
    }

    #[test]
    fn content_title_is_the_file_name() {
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir.clone());
        app.pump_one();
        app.dispatch_for_test(Intent::CursorDown); // alpha.txt (subdir is index 0)
        app.dispatch_for_test(Intent::CursorRight);
        app.pump_one(); // content read → the content provider stashes it + the path
        assert_eq!(app.function_title().as_deref(), Some("alpha.txt"), "title is the file name");
    }

    #[test]
    fn preview_extension_owns_function_panel_search_keys() {
        use crate::core::{Key, KeyCode};
        // The preview extension registers its function-panel bindings (search,
        // horizontal scroll) via scheme_source at the Extension layer; they
        // resolve through the live keymap and override the core bindings by
        // layer priority while a search is active.
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir);
        app.pump_one();
        app.state.function.visible = true;
        app.state.function.sublayout = SubLayout::Content;
        app.state.focused_panel = "function".into();
        let ch = |c| Key::plain(KeyCode::Char(c));
        let enter = Key::plain(KeyCode::Enter);
        let resolve = |app: &App, k| app.keymap.resolve(&app.conditions, &app.state, "function", k);

        // Extension-owned bindings: `/` opens search, h/l scroll horizontally.
        assert_eq!(resolve(&app, ch('/')), Some(Intent::FunctionSearchStart));
        assert_eq!(resolve(&app, ch('h')), Some(Intent::FuncLeft));
        // n toggles line numbers (core) until a search has matches, then the
        // extension's n (Extension layer) wins and walks matches.
        assert_eq!(resolve(&app, ch('n')), Some(Intent::ToggleLineNumbers));
        app.state.function.search.matches = vec![(0, 0, 1)];
        assert_eq!(resolve(&app, ch('n')), Some(Intent::FunctionSearchNext));
        assert_eq!(resolve(&app, ch('p')), Some(Intent::FunctionSearchPrev));
        // Enter opens (core) normally; submits (extension) while input is open.
        assert_eq!(resolve(&app, enter), Some(Intent::Open { path: std::path::PathBuf::new() }));
        app.state.function.search.input_active = true;
        assert_eq!(resolve(&app, enter), Some(Intent::FunctionSearchSubmit));
    }

    #[test]
    fn command_palette_filters_and_runs() {
        let dir = temp_dir_with_files();
        let mut app = App::boot(dir);
        app.pump_one();
        app.dispatch_for_test(Intent::PushMode(Box::new(Mode::Select(
            crate::core::SelectSpec::command_palette(Vec::new()),
        ))));
        // Candidates filled from the registry.
        let n = app.state.select.as_ref().unwrap().results.len();
        assert!(n > 5, "palette has the default commands");
    }
}
